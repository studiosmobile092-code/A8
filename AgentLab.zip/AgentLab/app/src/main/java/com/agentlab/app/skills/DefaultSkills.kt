package com.agentlab.app.skills

class DefaultSkill(val name: String, val description: String, val code: String)

/**
 * Starter skills. Each is plain JavaScript run in QuickJS. Tools (synchronous):
 *   tools.fetch_url({url})                          -> {url,title,text,links[]}
 *   tools.web_search({query,limit})                 -> [{title,url,snippet}]
 *   tools.read_knowledge({query,limit})             -> [{id,title,summary,url,confidence}]
 *   tools.save_knowledge({title,summary,url,confidence}) -> {id} | {duplicate:true}
 *   tools.call_llm({prompt,system,temperature,maxTokens}) -> string
 *   tools.run_skill({name,input})                   -> any
 * A skill defines function run(input) and returns a JSON-serialisable value.
 */
object DefaultSkills {
    val all = listOf(
        DefaultSkill(
            "summarize_url",
            "Reads a URL and returns a bullet-point summary. Input: {url}",
            """
function run(input) {
  if (!input.url) throw new Error("input.url is required");
  var page = tools.fetch_url({ url: input.url });
  var summary = tools.call_llm({
    system: "You write accurate, dense summaries. Never invent facts.",
    prompt: "Summarize the key facts of this page as concise bullet points.\n\nTITLE: " + page.title + "\n\n" + page.text.slice(0, 12000),
    maxTokens: 900
  });
  return { title: page.title, url: page.url, summary: summary };
}
""".trimIndent()
        ),
        DefaultSkill(
            "research_topic",
            "Searches the web for a topic, reads the top results and saves what it learns. Input: {topic, limit?}",
            """
function run(input) {
  if (!input.topic) throw new Error("input.topic is required");
  var results = tools.web_search({ query: input.topic, limit: input.limit || 3 });
  var saved = [];
  for (var i = 0; i < results.length; i++) {
    try {
      var page = tools.fetch_url({ url: results[i].url });
      var facts = tools.call_llm({
        system: "Extract only facts stated in the text. Output 3-6 short bullet points.",
        prompt: "Topic: " + input.topic + "\n\n" + page.text.slice(0, 10000),
        maxTokens: 600
      });
      var r = tools.save_knowledge({ title: page.title, summary: facts, url: page.url, confidence: 0.6 });
      saved.push({ url: page.url, result: r });
    } catch (e) {
      saved.push({ url: results[i].url, error: String(e.message || e) });
    }
  }
  return { topic: input.topic, saved: saved };
}
""".trimIndent()
        ),
        DefaultSkill(
            "answer_from_knowledge",
            "Answers a question using only the knowledge base. Input: {question}",
            """
function run(input) {
  if (!input.question) throw new Error("input.question is required");
  var hits = tools.read_knowledge({ query: input.question, limit: 5 });
  if (hits.length === 0) return { answer: "The knowledge base has nothing about this yet.", sources: [] };
  var ctx = hits.map(function (h, i) { return "[" + (i + 1) + "] " + h.title + ": " + h.summary; }).join("\n");
  var answer = tools.call_llm({
    system: "Answer only from the numbered excerpts and cite them like [1]. If they are insufficient, say so.",
    prompt: "EXCERPTS:\n" + ctx + "\n\nQUESTION: " + input.question,
    temperature: 0.2
  });
  return { answer: answer, sources: hits.map(function (h) { return h.url; }) };
}
""".trimIndent()
        ),
        DefaultSkill(
            "build_website",
            "Generates a complete single-file website (HTML+CSS+JS) from a brief. Input: {brief}",
            """
function run(input) {
  if (!input.brief) throw new Error("input.brief is required");
  var ctx = tools.read_knowledge({ query: input.brief, limit: 5 })
    .map(function (k) { return "- " + k.title + ": " + k.summary; }).join("\n");
  var html = tools.call_llm({
    system: "You are an expert front-end developer. Output ONLY one complete, self-contained HTML file with inline CSS and JS. No commentary and no code fences.",
    prompt: "Build: " + input.brief + "\n\nRelevant knowledge:\n" + ctx,
    temperature: 0.4,
    maxTokens: 6000
  });
  html = html.replace(/^```[a-zA-Z]*\n?/, "").replace(/```\s*$/, "");
  return { html: html };
}
""".trimIndent()
        )
    )
}
