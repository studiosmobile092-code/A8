package com.agentlab.app.agent

import com.agentlab.app.Container
import com.agentlab.app.data.ImprovementEntity
import com.agentlab.app.data.TestQuestionEntity
import com.agentlab.app.llm.LlmMessage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

fun pct(f: Float): String = String.format(Locale.US, "%.0f%%", f * 100)

/** Applies or rejects a stored improvement. Used by auto-approve and by the Approve/Reject buttons. */
class ChangeApplier(private val c: Container) {
    /** Returns an error message, or null on success. */
    suspend fun apply(id: Long, auto: Boolean): String? {
        val imp = c.db.improvements().get(id) ?: return "Improvement not found"
        if (imp.status != "PENDING" && !(auto && imp.status == "TESTED")) return "Already ${imp.status}"
        when (imp.kind) {
            "PROMPT" -> c.settings.update { it.copy(systemPrompt = imp.newText) }
            "STRATEGY" -> c.settings.update { it.copy(researchStrategy = imp.newText) }
            "SKILL" -> {
                val existing = c.db.skills().get(imp.target) ?: return "Skill ${imp.target} no longer exists"
                val r = c.skills.save(imp.target, existing.description, imp.newText, "Agent improvement #${imp.id}: ${imp.reason}".take(200))
                if (!r.ok) return r.error
            }
        }
        c.db.improvements().update(imp.copy(status = if (auto) "AUTO_APPLIED" else "APPLIED"))
        return null
    }

    suspend fun reject(id: Long) {
        val imp = c.db.improvements().get(id) ?: return
        if (imp.status == "PENDING") c.db.improvements().update(imp.copy(status = "REJECTED"))
    }
}

/** IMPROVE + TEST CHANGES phases. */
class Improver(
    private val c: Container,
    private val log: AgentLogger,
    private val researcher: Researcher,
    private val evaluator: Evaluator,
    private val applier: ChangeApplier
) {
    companion object {
        const val MARGIN = 0.005f
        const val PROPOSE_SYSTEM =
            "You improve an AI research agent. You see its weak answers and its current configuration. Propose targeted changes that would fix the weak spots. " +
                "Return ONLY JSON of this shape (omit a kind if you have no good idea for it, at most one change per kind):\n" +
                "{\"changes\":[\n" +
                " {\"kind\":\"PROMPT\",\"reason\":\"...\",\"new_text\":\"the complete new system prompt\"},\n" +
                " {\"kind\":\"STRATEGY\",\"reason\":\"...\",\"new_text\":\"the complete new research strategy\"},\n" +
                " {\"kind\":\"SKILL\",\"target\":\"existing_skill_name\",\"reason\":\"...\",\"new_text\":\"complete JavaScript defining function run(input)\",\"test_inputs\":[{...},{...}]}\n" +
                "]}\n" +
                "Skill code is synchronous JavaScript and may only use tools.fetch_url, tools.web_search, tools.read_knowledge, tools.save_knowledge, tools.call_llm, tools.run_skill. " +
                "Keep the skill's input/output contract the same. The system prompt must keep instructing the agent to cite knowledge-base excerpts like [1]."
    }

    suspend fun run(runId: Long, baseline: EvalResult, questions: List<TestQuestionEntity>): Int {
        val s = c.settings.current
        val weak = baseline.details.filter { it.score < 0.7f }.sortedBy { it.score }.take(8)
        if (weak.isEmpty()) {
            log.info("No weak spots: every answer scored at least 70%. Nothing to improve.")
            return 0
        }
        val skills = c.db.skills().getAll().filter { it.enabled }.take(5)
        val prompt = buildString {
            append("CURRENT SYSTEM PROMPT:\n${s.systemPrompt}\n\nCURRENT RESEARCH STRATEGY:\n${s.researchStrategy}\n\nSKILLS:\n")
            skills.forEach { append("--- ${it.name}: ${it.description}\n${it.code.take(2500)}\n") }
            append("\nWEAK ANSWERS (score, question, answer, grader note):\n")
            weak.forEach { append("- ${pct(it.score)} | ${it.question} | ${it.answer.take(300)} | ${it.note}\n") }
        }
        log.phase("IMPROVE: asking the model for changes based on ${weak.size} weak answers")
        val out = c.llm.complete(listOf(LlmMessage("user", prompt)), PROPOSE_SYSTEM, temperature = 0.4f, maxTokens = 6000)
        val changes = try {
            JSONObject(extractJsonObject(out) ?: throw IllegalStateException("no JSON")).optJSONArray("changes") ?: JSONArray()
        } catch (e: Exception) {
            log.warn("Could not parse the proposed changes: ${e.message}")
            return 0
        }
        var current = baseline.score
        var currentPrompt = s.systemPrompt
        var proposed = 0
        for (i in 0 until minOf(changes.length(), 3)) {
            currentCoroutineContext().ensureActive()
            val ch = changes.optJSONObject(i) ?: continue
            val kind = ch.optString("kind").uppercase()
            val reason = ch.optString("reason").ifBlank { "(no reason given)" }
            val newText = ch.optString("new_text")
            if (newText.isBlank()) continue
            proposed++
            log.phase("TEST CHANGES: $kind — $reason")
            try {
                val imp = when (kind) {
                    "PROMPT" -> testPrompt(runId, reason, currentPrompt, newText, current, questions)
                    "STRATEGY" -> testStrategy(runId, reason, newText, current, currentPrompt, questions)
                    "SKILL" -> testSkill(runId, reason, ch.optString("target"), newText, ch.optJSONArray("test_inputs"), questions)
                    else -> null
                } ?: continue
                val improved = imp.scoreAfter > imp.scoreBefore + MARGIN
                val status = if (!improved) "ROLLED_BACK" else if (c.settings.current.autoApprove) "TESTED" else "PENDING"
                val id = c.db.improvements().insert(imp.copy(status = status))
                log.info("  score ${pct(imp.scoreBefore)} -> ${pct(imp.scoreAfter)}: " + if (improved) "improved" else "no gain, rolled back automatically")
                if (status == "TESTED") {
                    val err = applier.apply(id, auto = true)
                    if (err == null) {
                        log.info("  auto-approved and applied")
                        if (kind == "PROMPT") { current = imp.scoreAfter; currentPrompt = newText }
                    } else log.warn("  auto-apply failed: $err")
                } else if (status == "PENDING") log.info("  waiting for your approval in the Agent tab")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                log.warn("  test failed: ${e.message}")
            }
        }
        return proposed
    }

    private suspend fun testPrompt(runId: Long, reason: String, old: String, new: String, before: Float, qs: List<TestQuestionEntity>): ImprovementEntity? {
        if (new.trim() == old.trim()) return null
        val after = evaluator.evaluatePrompt(qs, new).score
        return ImprovementEntity(runId = runId, kind = "PROMPT", target = "system_prompt", reason = reason, oldText = old, newText = new, status = "", scoreBefore = before, scoreAfter = after)
    }

    private suspend fun testStrategy(runId: Long, reason: String, new: String, before: Float, prompt: String, qs: List<TestQuestionEntity>): ImprovementEntity? {
        val old = c.settings.current.researchStrategy
        if (new.trim() == old.trim()) return null
        if (researcher.samplePages.isEmpty()) {
            log.warn("  no pages were read this run, so a research-strategy change cannot be tested")
            return null
        }
        val tempIds = ArrayList<Long>()
        try {
            for (p in researcher.samplePages) researcher.learn(p, new, tempIds)
            log.info("  re-read ${researcher.samplePages.size} sample pages with the new strategy: +${tempIds.size} entries (temporary)")
            val after = evaluator.evaluatePrompt(qs, prompt).score
            return ImprovementEntity(runId = runId, kind = "STRATEGY", target = "research_strategy", reason = reason, oldText = old, newText = new, status = "", scoreBefore = before, scoreAfter = after)
        } finally {
            tempIds.forEach { c.knowledge.delete(it) } // sandbox: nothing persists
        }
    }

    private suspend fun testSkill(runId: Long, reason: String, target: String, new: String, inputs: JSONArray?, qs: List<TestQuestionEntity>): ImprovementEntity? {
        val skill = c.db.skills().get(target)
        if (skill == null) {
            log.warn("  skill '$target' does not exist")
            return null
        }
        if (new.trim() == skill.code.trim()) return null
        val check = c.runner.run(new, "{}", timeoutMs = 15_000, check = true)
        if (!check.ok) {
            log.warn("  proposed code for '$target' does not load: ${check.value}")
            return ImprovementEntity(runId = runId, kind = "SKILL", target = target, reason = "$reason (code did not load)", oldText = skill.code, newText = new, status = "", scoreBefore = 0f, scoreAfter = 0f)
        }
        val (b, a) = if (skill.code.contains("input.question")) {
            evaluator.evaluateAnswerSkill(qs, skill.code).score to evaluator.evaluateAnswerSkill(qs, new).score
        } else {
            val ins = (0 until (inputs?.length() ?: 0)).mapNotNull { inputs?.optJSONObject(it)?.toString() }.take(3)
            if (ins.isEmpty()) { log.warn("  no test inputs for '$target'; cannot test"); return null }
            evaluator.evaluateGenericSkill(skill.description, skill.code, ins).score to evaluator.evaluateGenericSkill(skill.description, new, ins).score
        }
        return ImprovementEntity(runId = runId, kind = "SKILL", target = target, reason = reason, oldText = skill.code, newText = new, status = "", scoreBefore = b, scoreAfter = a)
    }
}
