package com.agentlab.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.agentlab.app.container
import com.agentlab.app.data.AppSettings
import com.agentlab.app.data.Defaults
import kotlinx.coroutines.launch

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 12.dp))
        content()
    }
}

@Composable
private fun Secret(label: String, value: String, onChange: (String) -> Unit) {
    var show by remember { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(
            value, onChange, label = { Text(label) }, singleLine = true, modifier = Modifier.weight(1f),
            visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, autoCorrectEnabled = false)
        )
        TextButton(onClick = { show = !show }) { Text(if (show) "Hide" else "Show") }
    }
}

@Composable
private fun NumField(label: String, value: Int, onChange: (Int) -> Unit) {
    OutlinedTextField(
        value.toString(),
        { v ->
            val digits = v.filter { it.isDigit() }.take(9)
            onChange(digits.toIntOrNull() ?: 0)
        },
        label = { Text(label) }, singleLine = true, modifier = Modifier.fillMaxWidth(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
    )
}

@Composable
fun SettingsScreen() {
    val c = LocalContext.current.container
    val saved by c.settings.flow.collectAsState()
    val tokens by c.settings.tokensToday.collectAsState()
    var d by remember { mutableStateOf(saved) }
    var note by remember { mutableStateOf<String?>(null) }
    var models by remember { mutableStateOf<List<String>?>(null) }
    val scope = rememberCoroutineScope()

    fun setProvider(p: String) {
        val m = when (p) {
            "GEMINI" -> "gemini-2.5-flash" to "gemini-embedding-001"
            "OPENAI" -> "gpt-4o-mini" to "text-embedding-3-small"
            else -> "claude-sonnet-4-5" to ""
        }
        d = d.copy(provider = p, model = m.first, embeddingModel = m.second)
    }

    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Settings", style = MaterialTheme.typography.titleLarge)
            Button(onClick = { c.settings.update { d }; note = "Saved" }) { Text("Save") }
        }
        note?.let { Text(it, color = MaterialTheme.colorScheme.primary) }

        Section("Model provider") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("GEMINI" to "Gemini", "OPENAI" to "OpenAI-compatible", "ANTHROPIC" to "Anthropic").forEach { (k, v) ->
                    FilterChip(d.provider == k, { setProvider(k) }, label = { Text(v) })
                }
            }
            if (d.provider == "OPENAI") OutlinedTextField(d.baseUrl, { d = d.copy(baseUrl = it) }, label = { Text("Base URL (OpenAI, Groq, OpenRouter, local…)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(d.model, { d = d.copy(model = it.trim()) }, label = { Text("Model") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedButton(onClick = {
                c.settings.update { d }
                scope.launch {
                    try { models = c.llm.listModels() } catch (e: Exception) { note = "Could not list models: ${e.message}" }
                }
            }) { Text("List available models") }
            Secret("API key (stored encrypted)", d.apiKey) { d = d.copy(apiKey = it.trim()) }
            OutlinedTextField(d.embeddingModel, { d = d.copy(embeddingModel = it.trim()) }, label = { Text("Embedding model (blank = on-device embeddings)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Text("Temperature ${"%.2f".format(d.temperature)}")
            Slider(d.temperature, { d = d.copy(temperature = it) }, valueRange = 0f..2f)
            NumField("Max tokens per reply", d.maxTokens) { d = d.copy(maxTokens = it.coerceAtLeast(16)) }
        }

        Section("System prompt") {
            OutlinedTextField(d.systemPrompt, { d = d.copy(systemPrompt = it) }, minLines = 6, maxLines = 16, modifier = Modifier.fillMaxWidth())
            TextButton(onClick = { d = d.copy(systemPrompt = Defaults.SYSTEM_PROMPT) }) { Text("Reset to default") }
        }

        Section("Research strategy") {
            OutlinedTextField(d.researchStrategy, { d = d.copy(researchStrategy = it) }, minLines = 4, maxLines = 12, modifier = Modifier.fillMaxWidth())
            TextButton(onClick = { d = d.copy(researchStrategy = Defaults.RESEARCH_STRATEGY) }) { Text("Reset to default") }
        }

        Section("Web search") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("DUCKDUCKGO" to "DuckDuckGo (no key)", "TAVILY" to "Tavily", "BRAVE" to "Brave").forEach { (k, v) ->
                    FilterChip(d.searchProvider == k, { d = d.copy(searchProvider = k) }, label = { Text(v) })
                }
            }
            if (d.searchProvider != "DUCKDUCKGO") Secret("Search API key (stored encrypted)", d.searchApiKey) { d = d.copy(searchApiKey = it.trim()) }
        }

        Section("GitHub") {
            Secret("Personal access token (stored encrypted)", d.githubToken) { d = d.copy(githubToken = it.trim()) }
            OutlinedTextField(d.githubRepo, { d = d.copy(githubRepo = it.trim()) }, label = { Text("Repository (owner/name)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(d.githubBaseBranch, { d = d.copy(githubBaseBranch = it.trim()) }, label = { Text("Base branch (never written to)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        }

        Section("Limits") {
            NumField("Max pages per run", d.maxPagesPerRun) { d = d.copy(maxPagesPerRun = it.coerceAtLeast(1)) }
            NumField("Link depth (0 = do not follow links)", d.maxLinkDepth) { d = d.copy(maxLinkDepth = it.coerceIn(0, 3)) }
            NumField("Daily token budget", d.dailyTokenBudget) { d = d.copy(dailyTokenBudget = it) }
            NumField("Test questions per evaluation", d.evalQuestionCap) { d = d.copy(evalQuestionCap = it.coerceIn(1, 50)) }
            Text("Tokens used today: $tokens of ${saved.dailyTokenBudget}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }

    models?.let { list ->
        AlertDialog(
            onDismissRequest = { models = null },
            title = { Text("Models (${list.size})") },
            text = {
                LazyColumn { items(list) { m -> TextButton(onClick = { d = d.copy(model = m); models = null }) { Text(m) } } }
            },
            confirmButton = { TextButton(onClick = { models = null }) { Text("Close") } }
        )
    }
}
