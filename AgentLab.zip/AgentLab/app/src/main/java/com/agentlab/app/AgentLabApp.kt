package com.agentlab.app

import android.app.Application
import android.content.Context
import com.agentlab.app.data.AppDb
import com.agentlab.app.data.SettingsStore
import com.agentlab.app.knowledge.KnowledgeBase
import com.agentlab.app.llm.Embedder
import com.agentlab.app.llm.LlmClient
import com.agentlab.app.skills.SkillManager
import com.agentlab.app.skills.SkillRunner
import com.agentlab.app.skills.Tools
import com.agentlab.app.web.WebReader
import com.agentlab.app.web.WebSearch
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

/** Wires every component once. Created lazily so the ":sandbox" process (which also instantiates Application) stays light. */
class Container(val context: Context) {
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    val db: AppDb by lazy { AppDb.create(context) }
    val settings: SettingsStore by lazy { SettingsStore(context) }
    val http: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(120, TimeUnit.SECONDS)
            .writeTimeout(60, TimeUnit.SECONDS)
            .followRedirects(true)
            .build()
    }
    val llm: LlmClient by lazy { LlmClient(settings, http) }
    val embedder: Embedder by lazy { Embedder(settings, http) }
    val knowledge: KnowledgeBase by lazy { KnowledgeBase(db, embedder) }
    val chat: com.agentlab.app.agent.ChatEngine by lazy { com.agentlab.app.agent.ChatEngine(llm, knowledge, settings) }
    val agent: com.agentlab.app.agent.AgentController by lazy { com.agentlab.app.agent.AgentController(this) }
    val applier: com.agentlab.app.agent.ChangeApplier by lazy { com.agentlab.app.agent.ChangeApplier(this) }
    val github: com.agentlab.app.github.GitHubClient by lazy { com.agentlab.app.github.GitHubClient(http, settings) }
    val selfEditor: com.agentlab.app.github.SelfEditor by lazy { com.agentlab.app.github.SelfEditor(this) }
    val chatController: com.agentlab.app.agent.ChatController by lazy { com.agentlab.app.agent.ChatController(this) }
    val web: WebReader by lazy { WebReader(context, http, settings) }
    val search: WebSearch by lazy { WebSearch(http, settings) }
    val runner: SkillRunner by lazy { SkillRunner(context, scope) }
    val skills: SkillManager by lazy { SkillManager(db, runner) }
    val tools: Tools by lazy {
        Tools(web, search, knowledge, llm).also {
            it.skills = skills
            runner.host = it
        }
    }

    suspend fun init() {
        tools // ensure wiring
        skills.ensureDefaults()
    }
}

class AgentLabApp : Application() {
    lateinit var container: Container
        private set

    override fun onCreate() {
        super.onCreate()
        container = Container(this)
    }
}

val Context.container: Container get() = (applicationContext as AgentLabApp).container
