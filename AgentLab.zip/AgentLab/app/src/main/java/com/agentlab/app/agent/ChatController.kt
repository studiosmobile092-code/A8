package com.agentlab.app.agent

import com.agentlab.app.Container
import com.agentlab.app.data.ChatMessageEntity
import com.agentlab.app.llm.LlmMessage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Owns the streaming chat so it keeps running while the user switches tabs. */
class ChatController(private val c: Container) {
    private val _streaming = MutableStateFlow<String?>(null)
    val streaming: StateFlow<String?> = _streaming
    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error
    private var job: Job? = null

    val busy: Boolean get() = job?.isActive == true

    fun clearError() { _error.value = null }

    fun send(text: String) {
        val q = text.trim()
        if (q.isEmpty() || busy) return
        _error.value = null
        job = c.scope.launch {
            val sb = StringBuilder()
            var hits = emptyList<com.agentlab.app.knowledge.Hit>()
            try {
                c.init()
                c.db.chat().insert(ChatMessageEntity(role = "user", content = q))
                val history = c.db.chat().recent(13).dropLast(1).map { LlmMessage(it.role, it.content) }
                val p = c.chat.prepare(q, history)
                hits = p.hits
                _streaming.value = ""
                c.chat.stream(p).collect {
                    sb.append(it)
                    _streaming.value = sb.toString()
                }
            } catch (e: CancellationException) {
                // user pressed stop: keep the partial answer
            } catch (e: Exception) {
                _error.value = e.message ?: e.javaClass.simpleName
            } finally {
                withContext(NonCancellable) {
                    if (sb.isNotBlank()) {
                        val text2 = sb.toString()
                        val cited = Regex("\\[(\\d{1,2})]").findAll(text2).map { it.groupValues[1].toInt() }.toSet()
                        val used = hits.withIndex().filter { cited.isEmpty() || (it.index + 1) in cited }
                        val cites = used.joinToString("\n") { "${it.index + 1}\t${it.value.entry.title.replace('\t', ' ')}\t${it.value.entry.sourceUrl}" }
                        c.db.chat().insert(ChatMessageEntity(role = "assistant", content = text2, citations = cites))
                    }
                    _streaming.value = null
                }
            }
        }
    }

    fun stop() { job?.cancel() }

    suspend fun clear() { c.db.chat().clear() }
}
