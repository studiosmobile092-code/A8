package com.agentlab.app.skills

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Message
import android.os.Messenger
import android.os.Process
import android.os.RemoteException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/** crashed = true when the script itself failed (exception, timeout, out of memory), false for tool/network errors. */
class SkillResult(val ok: Boolean, val value: String, val crashed: Boolean = false)

fun interface ToolHost {
    /** Returns a JSON string: {"value": ...} or {"error": "..."} */
    suspend fun call(tool: String, argsJson: String, depth: Int): String
}

class SkillRunner(private val context: Context, private val scope: CoroutineScope) {
    @Volatile var host: ToolHost? = null

    private class Run(val deferred: CompletableDeferred<SkillResult>, val depth: Int) {
        @Volatile var pid = 0
    }

    private val runs = ConcurrentHashMap<String, Run>()
    @Volatile private var service: Messenger? = null
    @Volatile private var bound: CompletableDeferred<Messenger>? = null
    private val lock = Any()
    private val incoming = Messenger(Handler(Looper.getMainLooper()) { m -> onMessage(m); true })

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder) {
            val m = Messenger(binder)
            service = m
            bound?.complete(m)
        }
        override fun onServiceDisconnected(name: ComponentName) = handleDeath()
        override fun onBindingDied(name: ComponentName) = handleDeath()
    }

    private fun handleDeath() {
        val wasBound: Boolean
        synchronized(lock) {
            wasBound = service != null || bound != null
            service = null
            bound?.completeExceptionally(IllegalStateException("Sandbox stopped"))
            bound = null
        }
        if (wasBound) try { context.unbindService(conn) } catch (_: Exception) {}
        val dead = runs.values.toList()
        runs.clear()
        dead.forEach { it.deferred.complete(SkillResult(false, "Sandbox process stopped", true)) }
    }

    private suspend fun ensure(): Messenger {
        service?.let { return it }
        val d = synchronized(lock) {
            bound ?: CompletableDeferred<Messenger>().also { def ->
                bound = def
                val ok = context.bindService(Intent(context, SandboxService::class.java), conn, Context.BIND_AUTO_CREATE)
                if (!ok) def.completeExceptionally(IllegalStateException("Cannot bind sandbox service"))
            }
        }
        return withTimeoutOrNull(10_000) { d.await() } ?: throw IllegalStateException("Sandbox did not start")
    }

    private fun message(runId: String, code: String, inputJson: String, memMb: Int, check: Boolean): Message {
        val m = Message.obtain(null, Sbx.RUN)
        m.replyTo = incoming
        m.data = Bundle().apply {
            putString("runId", runId); putString("code", code); putString("input", inputJson)
            putLong("memBytes", memMb.toLong() * 1024 * 1024); putBoolean("check", check)
        }
        return m
    }

    suspend fun run(
        code: String,
        inputJson: String,
        timeoutMs: Long = 90_000,
        depth: Int = 0,
        check: Boolean = false,
        memMb: Int = 32
    ): SkillResult {
        val runId = UUID.randomUUID().toString()
        val r = Run(CompletableDeferred(), depth)
        runs[runId] = r
        try {
            var svc = ensure()
            try {
                svc.send(message(runId, code, inputJson, memMb, check))
            } catch (e: RemoteException) {
                handleDeath()
                runs[runId] = r
                svc = ensure()
                svc.send(message(runId, code, inputJson, memMb, check))
            }
            val res = withTimeoutOrNull(timeoutMs) { r.deferred.await() }
            if (res != null) return res
            killSandbox(r)
            return SkillResult(false, "Timed out after ${timeoutMs / 1000}s; the sandbox was killed", true)
        } catch (e: CancellationException) {
            killSandbox(r)
            throw e
        } catch (e: Exception) {
            return SkillResult(false, e.message ?: "Sandbox error", true)
        } finally {
            runs.remove(runId)
        }
    }

    private fun killSandbox(r: Run) {
        val pid = r.pid
        if (pid != 0) try { Process.killProcess(pid) } catch (_: Exception) {}
        handleDeath()
    }

    private fun onMessage(m: Message) {
        val d = m.data
        val runId = d.getString("runId").orEmpty()
        when (m.what) {
            Sbx.HELLO -> runs[runId]?.pid = d.getInt("pid")
            Sbx.RESULT -> {
                val ok = d.getBoolean("ok")
                val v = d.getString("value").orEmpty()
                runs[runId]?.deferred?.complete(SkillResult(ok, v, !ok && !v.contains("TOOL:")))
            }
            Sbx.TOOL_CALL -> {
                val run = runs[runId] ?: return
                val callId = d.getString("callId").orEmpty()
                val tool = d.getString("tool").orEmpty()
                val args = d.getString("args").orEmpty()
                scope.launch {
                    val reply = try {
                        host?.call(tool, args, run.depth) ?: "{\"error\":\"tools unavailable\"}"
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        "{\"error\":" + JSONObject.quote(e.message ?: "tool failed") + "}"
                    }
                    try {
                        val msg = Message.obtain(null, Sbx.TOOL_REPLY)
                        msg.data = Bundle().apply { putString("callId", callId); putString("value", reply) }
                        service?.send(msg)
                    } catch (_: Exception) {
                    }
                }
            }
        }
    }
}
