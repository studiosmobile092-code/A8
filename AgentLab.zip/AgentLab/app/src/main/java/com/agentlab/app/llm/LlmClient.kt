package com.agentlab.app.llm

import com.agentlab.app.data.AppSettings
import com.agentlab.app.data.SettingsStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.addJsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import kotlinx.serialization.json.putJsonObject
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import java.io.IOException
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

data class LlmMessage(val role: String, val content: String) // role: "user" | "assistant"

class LlmException(message: String) : Exception(message)
class BudgetExceededException(message: String) : Exception(message)

suspend fun Call.await(): Response = suspendCancellableCoroutine { cont ->
    cont.invokeOnCancellation { cancel() }
    enqueue(object : Callback {
        override fun onFailure(call: Call, e: IOException) {
            if (cont.isActive) cont.resumeWithException(e)
        }
        override fun onResponse(call: Call, response: Response) {
            if (cont.isActive) cont.resume(response) else response.close()
        }
    })
}

fun estimateTokens(chars: Int): Int = (chars / 4).coerceAtLeast(1)

internal fun JsonElement?.asObj(): JsonObject? = this as? JsonObject
internal fun JsonElement?.asArr(): JsonArray? = this as? JsonArray
internal fun JsonElement?.str(): String? = (this as? JsonPrimitive)?.contentOrNull

class LlmClient(private val settings: SettingsStore, val http: OkHttpClient) {
    private val json = Json { ignoreUnknownKeys = true }
    private val jsonType = "application/json".toMediaType()

    private class OaiCompat(var maxCompletion: Boolean = false, var omitTemp: Boolean = false)
    private val oai = OaiCompat()

    private class Chunk(val text: String, val total: Int? = null, val inTok: Int? = null, val outTok: Int? = null)

    private fun checkBudget() {
        if (settings.budgetRemaining() <= 0) {
            throw BudgetExceededException("Daily token budget of ${settings.current.dailyTokenBudget} reached. Raise it in Settings or wait until tomorrow.")
        }
    }

    private fun normalize(m: List<LlmMessage>): List<LlmMessage> {
        val out = ArrayList<LlmMessage>()
        for (x in m) {
            if (x.content.isBlank()) continue
            if (out.isNotEmpty() && out.last().role == x.role) {
                out[out.size - 1] = LlmMessage(x.role, out.last().content + "\n\n" + x.content)
            } else out.add(x)
        }
        while (out.isNotEmpty() && out.first().role != "user") out.removeAt(0)
        if (out.isEmpty()) throw LlmException("No message to send.")
        return out
    }

    suspend fun complete(
        messages: List<LlmMessage>,
        system: String? = null,
        temperature: Float? = null,
        maxTokens: Int? = null
    ): String {
        checkBudget()
        val s = settings.current
        val msgs = normalize(messages)
        val t = temperature ?: s.temperature
        val mt = maxTokens ?: s.maxTokens
        val resp = sendWithRetry(s) { buildRequest(s, msgs, system, t, mt, false) }
        resp.use { r ->
            val body = withContext(Dispatchers.IO) { r.body?.string().orEmpty() }
            val obj = try {
                json.parseToJsonElement(body).jsonObject
            } catch (e: Exception) {
                throw LlmException("Unreadable response from provider: ${body.take(200)}")
            }
            val (text, used) = parseComplete(s.provider, obj)
            account(used ?: estimateTokens(msgs.sumOf { it.content.length } + (system?.length ?: 0) + text.length))
            if (text.isBlank()) throw LlmException("The model returned an empty reply (it may have been blocked or hit the token limit).")
            return text
        }
    }

    fun stream(
        messages: List<LlmMessage>,
        system: String? = null,
        temperature: Float? = null,
        maxTokens: Int? = null
    ): Flow<String> = flow {
        checkBudget()
        val s = settings.current
        val msgs = normalize(messages)
        val t = temperature ?: s.temperature
        val mt = maxTokens ?: s.maxTokens
        val resp = sendWithRetry(s) { buildRequest(s, msgs, system, t, mt, true) }
        var outChars = 0
        var total: Int? = null
        var inTok = 0
        var outTok = 0
        try {
            resp.use { r ->
                val source = r.body!!.source()
                while (true) {
                    currentCoroutineContext().ensureActive()
                    val line = source.readUtf8Line() ?: break
                    if (!line.startsWith("data:")) continue
                    val payload = line.substring(5).trim()
                    if (payload.isEmpty()) continue
                    if (payload == "[DONE]") break
                    val obj = try {
                        json.parseToJsonElement(payload).jsonObject
                    } catch (e: Exception) {
                        continue
                    }
                    val c = parseChunk(s.provider, obj)
                    if (c.total != null) total = c.total
                    if (c.inTok != null) inTok = c.inTok
                    if (c.outTok != null) outTok = c.outTok
                    if (c.text.isNotEmpty()) {
                        outChars += c.text.length
                        emit(c.text)
                    }
                }
            }
        } finally {
            val used = total ?: if (inTok + outTok > 0) inTok + outTok else null
            account(used ?: estimateTokens(msgs.sumOf { it.content.length } + (system?.length ?: 0) + outChars))
        }
    }.flowOn(Dispatchers.IO)

    suspend fun listModels(): List<String> {
        val s = settings.current
        val req = when (s.provider) {
            "GEMINI" -> Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models?pageSize=200")
                .header("x-goog-api-key", requireKey(s)).build()
            "ANTHROPIC" -> Request.Builder()
                .url("https://api.anthropic.com/v1/models?limit=100")
                .header("x-api-key", requireKey(s)).header("anthropic-version", "2023-06-01").build()
            else -> {
                val b = Request.Builder().url(s.baseUrl.trimEnd('/') + "/models")
                if (s.apiKey.isNotBlank()) b.header("Authorization", "Bearer ${s.apiKey}")
                b.build()
            }
        }
        val resp = http.newCall(req).await()
        resp.use { r ->
            val body = withContext(Dispatchers.IO) { r.body?.string().orEmpty() }
            if (!r.isSuccessful) throw LlmException("HTTP ${r.code}: ${extractError(body)}")
            val obj = json.parseToJsonElement(body).jsonObject
            val names: List<String> = if (s.provider == "GEMINI") {
                obj["models"].asArr().orEmpty().mapNotNull { m ->
                    val o = m.asObj() ?: return@mapNotNull null
                    val methods = o["supportedGenerationMethods"].asArr().orEmpty().mapNotNull { it.str() }
                    if (methods.contains("generateContent")) o["name"].str()?.removePrefix("models/") else null
                }
            } else {
                obj["data"].asArr().orEmpty().mapNotNull { it.asObj()?.get("id").str() }
            }
            return names.sorted()
        }
    }

    // ---------- internals ----------

    private fun requireKey(s: AppSettings): String {
        if (s.apiKey.isBlank()) throw LlmException("API key is not set. Open Settings and enter your API key.")
        return s.apiKey
    }

    private fun account(tokens: Int) {
        if (tokens > 0) settings.addTokens(tokens)
    }

    private suspend fun sendWithRetry(s: AppSettings, build: () -> Request): Response {
        var attempt = 0
        while (true) {
            val resp = http.newCall(build()).await()
            if (resp.isSuccessful) return resp
            val code = resp.code
            val body = withContext(Dispatchers.IO) { resp.body?.string().orEmpty() }
            resp.close()
            if (s.provider == "OPENAI" && code == 400 && attempt < 3) {
                if (body.contains("max_completion_tokens") && !oai.maxCompletion) {
                    oai.maxCompletion = true; attempt++; continue
                }
                if (body.contains("temperature") && !oai.omitTemp) {
                    oai.omitTemp = true; attempt++; continue
                }
            }
            if ((code == 429 || code == 500 || code == 502 || code == 503) && attempt < 3) {
                attempt++
                delay(2000L * attempt)
                continue
            }
            throw LlmException("HTTP $code: ${extractError(body)}")
        }
    }

    private fun extractError(body: String): String {
        return try {
            val o = json.parseToJsonElement(body).jsonObject
            val e = o["error"]
            e.asObj()?.get("message").str() ?: e.str() ?: body.take(300)
        } catch (ex: Exception) {
            body.take(300)
        }
    }

    private fun buildRequest(
        s: AppSettings, msgs: List<LlmMessage>, system: String?, t: Float, mt: Int, stream: Boolean
    ): Request {
        return when (s.provider) {
            "GEMINI" -> {
                val body = buildJsonObject {
                    if (!system.isNullOrBlank()) {
                        putJsonObject("systemInstruction") {
                            putJsonArray("parts") { addJsonObject { put("text", system) } }
                        }
                    }
                    putJsonArray("contents") {
                        for (m in msgs) addJsonObject {
                            put("role", if (m.role == "assistant") "model" else "user")
                            putJsonArray("parts") { addJsonObject { put("text", m.content) } }
                        }
                    }
                    putJsonObject("generationConfig") {
                        put("temperature", t.toDouble())
                        put("maxOutputTokens", mt)
                    }
                }
                val url = "https://generativelanguage.googleapis.com/v1beta/models/${s.model}:" +
                    if (stream) "streamGenerateContent?alt=sse" else "generateContent"
                Request.Builder().url(url)
                    .header("x-goog-api-key", requireKey(s))
                    .post(body.toString().toRequestBody(jsonType)).build()
            }
            "ANTHROPIC" -> {
                val body = buildJsonObject {
                    put("model", s.model)
                    put("max_tokens", mt)
                    put("temperature", t.toDouble().coerceIn(0.0, 1.0))
                    if (!system.isNullOrBlank()) put("system", system)
                    if (stream) put("stream", true)
                    putJsonArray("messages") {
                        for (m in msgs) addJsonObject {
                            put("role", m.role)
                            put("content", m.content)
                        }
                    }
                }
                Request.Builder().url("https://api.anthropic.com/v1/messages")
                    .header("x-api-key", requireKey(s))
                    .header("anthropic-version", "2023-06-01")
                    .post(body.toString().toRequestBody(jsonType)).build()
            }
            else -> {
                val body = buildJsonObject {
                    put("model", s.model)
                    if (!oai.omitTemp) put("temperature", t.toDouble())
                    put(if (oai.maxCompletion) "max_completion_tokens" else "max_tokens", mt)
                    if (stream) put("stream", true)
                    putJsonArray("messages") {
                        if (!system.isNullOrBlank()) addJsonObject { put("role", "system"); put("content", system) }
                        for (m in msgs) addJsonObject { put("role", m.role); put("content", m.content) }
                    }
                }
                val b = Request.Builder().url(s.baseUrl.trimEnd('/') + "/chat/completions")
                if (s.apiKey.isNotBlank()) b.header("Authorization", "Bearer ${s.apiKey}")
                b.post(body.toString().toRequestBody(jsonType)).build()
            }
        }
    }

    private fun parseComplete(provider: String, o: JsonObject): Pair<String, Int?> {
        return when (provider) {
            "GEMINI" -> {
                val parts = o["candidates"].asArr()?.firstOrNull().asObj()
                    ?.get("content").asObj()?.get("parts").asArr().orEmpty()
                val text = parts.mapNotNull { p ->
                    val po = p.asObj() ?: return@mapNotNull null
                    if (po["thought"].str() == "true") null else po["text"].str()
                }.joinToString("")
                text to o["usageMetadata"].asObj()?.get("totalTokenCount").let { (it as? JsonPrimitive)?.intOrNull }
            }
            "ANTHROPIC" -> {
                val text = o["content"].asArr().orEmpty().mapNotNull { c ->
                    val co = c.asObj() ?: return@mapNotNull null
                    if (co["type"].str() == "text") co["text"].str() else null
                }.joinToString("")
                val u = o["usage"].asObj()
                val used = ((u?.get("input_tokens") as? JsonPrimitive)?.intOrNull ?: 0) +
                    ((u?.get("output_tokens") as? JsonPrimitive)?.intOrNull ?: 0)
                text to (if (used > 0) used else null)
            }
            else -> {
                val text = o["choices"].asArr()?.firstOrNull().asObj()?.get("message").asObj()?.get("content").str().orEmpty()
                text to (o["usage"].asObj()?.get("total_tokens") as? JsonPrimitive)?.intOrNull
            }
        }
    }

    private fun parseChunk(provider: String, o: JsonObject): Chunk {
        return when (provider) {
            "GEMINI" -> {
                val parts = o["candidates"].asArr()?.firstOrNull().asObj()
                    ?.get("content").asObj()?.get("parts").asArr().orEmpty()
                val text = parts.mapNotNull { p ->
                    val po = p.asObj() ?: return@mapNotNull null
                    if (po["thought"].str() == "true") null else po["text"].str()
                }.joinToString("")
                val total = (o["usageMetadata"].asObj()?.get("totalTokenCount") as? JsonPrimitive)?.intOrNull
                Chunk(text, total = total)
            }
            "ANTHROPIC" -> {
                when (o["type"].str()) {
                    "content_block_delta" ->
                        Chunk(o["delta"].asObj()?.get("text").str().orEmpty())
                    "message_start" -> Chunk(
                        "",
                        inTok = (o["message"].asObj()?.get("usage").asObj()?.get("input_tokens") as? JsonPrimitive)?.intOrNull
                    )
                    "message_delta" -> Chunk(
                        "",
                        outTok = (o["usage"].asObj()?.get("output_tokens") as? JsonPrimitive)?.intOrNull
                    )
                    else -> Chunk("")
                }
            }
            else -> {
                val text = o["choices"].asArr()?.firstOrNull().asObj()?.get("delta").asObj()?.get("content").str().orEmpty()
                val total = (o["usage"].asObj()?.get("total_tokens") as? JsonPrimitive)?.intOrNull
                Chunk(text, total = total)
            }
        }
    }
}
