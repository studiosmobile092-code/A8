package com.agentlab.app.skills

import android.app.Service
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Message
import android.os.Messenger
import android.os.Process
import app.cash.quickjs.QuickJs
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

/** Message protocol between the app process and the sandbox process. */
object Sbx {
    const val HELLO = 1       // sandbox -> app: pid
    const val RUN = 2         // app -> sandbox: runId, code, input, memBytes
    const val TOOL_CALL = 3   // sandbox -> app: runId, callId, tool, args
    const val TOOL_REPLY = 4  // app -> sandbox: callId, value (JSON string {value|error})
    const val RESULT = 5      // sandbox -> app: runId, ok, value
}

/** The only object exposed to skill JavaScript. Nothing else on the device is reachable. */
interface HostApi {
    fun call(tool: String, argsJson: String): String
    fun input(): String
}

/**
 * Runs skill code in QuickJS inside a separate Android process (":sandbox").
 * The app process enforces the wall-clock timeout by killing this process, so even an
 * infinite loop in a skill cannot hang or crash the app.
 */
class SandboxService : Service() {
    private val replies = ConcurrentHashMap<String, LinkedBlockingQueue<String>>()
    private lateinit var messenger: Messenger

    override fun onCreate() {
        super.onCreate()
        messenger = Messenger(Handler(Looper.getMainLooper()) { msg -> handle(msg); true })
    }

    override fun onBind(intent: Intent?): IBinder = messenger.binder

    private fun handle(msg: Message) {
        val d = msg.data
        when (msg.what) {
            Sbx.RUN -> {
                val replyTo = msg.replyTo ?: return
                val runId = d.getString("runId").orEmpty()
                send(replyTo, Sbx.HELLO) { putString("runId", runId); putInt("pid", Process.myPid()) }
                val code = d.getString("code").orEmpty()
                val input = d.getString("input") ?: "{}"
                val mem = d.getLong("memBytes", 32L * 1024 * 1024)
                val check = d.getBoolean("check", false)
                thread(name = "skill-$runId", isDaemon = true) { execute(replyTo, runId, code, input, mem, check) }
            }
            Sbx.TOOL_REPLY -> {
                replies[d.getString("callId").orEmpty()]?.offer(d.getString("value").orEmpty())
            }
        }
    }

    private fun send(to: Messenger, what: Int, fill: Bundle.() -> Unit) {
        try {
            val m = Message.obtain(null, what)
            m.data = Bundle().apply(fill)
            to.send(m)
        } catch (_: Exception) {
        }
    }

    /** Applies a QuickJS limit by name; if this library version lacks the setter the process-level timeout/kill still applies. */
    private fun setLimit(js: Any, setter: String, value: Long) {
        try {
            js.javaClass.getMethod(setter, java.lang.Long.TYPE).invoke(js, value)
        } catch (_: Throwable) {
        }
    }

    private fun errJson(msg: String): String =
        "{\"error\":" + org.json.JSONObject.quote(msg) + "}"

    private fun execute(replyTo: Messenger, runId: String, code: String, input: String, mem: Long, check: Boolean) {
        var js: QuickJs? = null
        try {
            js = QuickJs.create()
            setLimit(js, "setMemoryLimit", mem)
            setLimit(js, "setMaxStackSize", 768L * 1024)
            js.set("host", HostApi::class.java, object : HostApi {
                override fun input(): String = input
                override fun call(tool: String, argsJson: String): String {
                    val callId = UUID.randomUUID().toString()
                    val q = LinkedBlockingQueue<String>(1)
                    replies[callId] = q
                    try {
                        send(replyTo, Sbx.TOOL_CALL) {
                            putString("runId", runId); putString("callId", callId)
                            putString("tool", tool); putString("args", argsJson)
                        }
                        return q.poll(180, TimeUnit.SECONDS) ?: errJson("tool call timed out")
                    } finally {
                        replies.remove(callId)
                    }
                }
            })
            js.evaluate(PRELUDE, "prelude.js")
            js.evaluate(code, "skill.js")
            if (check) {
                val ok = js.evaluate("typeof run === 'function' ? 'ok' : 'Skill must define function run(input)'", "check.js")
                if (ok == "ok") {
                    send(replyTo, Sbx.RESULT) { putString("runId", runId); putBoolean("ok", true); putString("value", "\"ok\"") }
                } else {
                    send(replyTo, Sbx.RESULT) { putString("runId", runId); putBoolean("ok", false); putString("value", ok.toString()) }
                }
                return
            }
            val out = js.evaluate(
                "(function(){ if (typeof run !== 'function') throw new Error('Skill must define function run(input)');" +
                    " var r = run(JSON.parse(host.input())); return JSON.stringify(r === undefined ? null : r); })()",
                "entry.js"
            )
            send(replyTo, Sbx.RESULT) { putString("runId", runId); putBoolean("ok", true); putString("value", out?.toString() ?: "null") }
        } catch (t: Throwable) {
            send(replyTo, Sbx.RESULT) {
                putString("runId", runId); putBoolean("ok", false)
                putString("value", (t.message ?: t.javaClass.simpleName).take(2000))
            }
        } finally {
            try { js?.close() } catch (_: Throwable) {}
        }
    }

    companion object {
        val TOOL_NAMES = listOf("fetch_url", "web_search", "read_knowledge", "save_knowledge", "call_llm", "run_skill")

        const val PRELUDE = """
var tools = {};
["fetch_url","web_search","read_knowledge","save_knowledge","call_llm","run_skill"].forEach(function(n){
  tools[n] = function(args){
    var r = JSON.parse(host.call(n, JSON.stringify(args === undefined ? {} : args)));
    if (r.error) throw new Error("TOOL: " + r.error);
    return r.value;
  };
});
var console = { log: function(){}, error: function(){}, warn: function(){} };
"""
    }
}
