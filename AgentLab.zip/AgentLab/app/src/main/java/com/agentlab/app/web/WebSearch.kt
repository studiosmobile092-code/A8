package com.agentlab.app.web

import com.agentlab.app.data.SettingsStore
import com.agentlab.app.llm.asArr
import com.agentlab.app.llm.asObj
import com.agentlab.app.llm.await
import com.agentlab.app.llm.str
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.put
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.jsoup.Jsoup

data class SearchResult(val title: String, val url: String, val snippet: String)

class WebSearch(private val http: OkHttpClient, private val settings: SettingsStore) {
    private val json = Json { ignoreUnknownKeys = true }

    suspend fun search(query: String, limit: Int = 5): List<SearchResult> {
        val q = query.trim()
        if (q.isEmpty()) return emptyList()
        val s = settings.current
        return when (s.searchProvider) {
            "TAVILY" -> tavily(q, limit, s.searchApiKey)
            "BRAVE" -> brave(q, limit, s.searchApiKey)
            else -> duckDuckGo(q, limit)
        }
    }

    private suspend fun tavily(q: String, limit: Int, key: String): List<SearchResult> {
        if (key.isBlank()) throw WebException("Tavily API key is not set (Settings > Search).")
        val body = buildJsonObject { put("query", q); put("max_results", limit) }
        val req = Request.Builder().url("https://api.tavily.com/search")
            .header("Authorization", "Bearer $key")
            .post(body.toString().toRequestBody("application/json".toMediaType())).build()
        val resp = http.newCall(req).await()
        resp.use { r ->
            val txt = withContext(Dispatchers.IO) { r.body?.string().orEmpty() }
            if (!r.isSuccessful) throw WebException("Tavily HTTP ${r.code}: ${txt.take(200)}")
            return json.parseToJsonElement(txt).jsonObject["results"].asArr().orEmpty().mapNotNull { e ->
                val o = e.asObj() ?: return@mapNotNull null
                val url = o["url"].str() ?: return@mapNotNull null
                SearchResult(o["title"].str() ?: url, url, o["content"].str().orEmpty().take(400))
            }
        }
    }

    private suspend fun brave(q: String, limit: Int, key: String): List<SearchResult> {
        if (key.isBlank()) throw WebException("Brave Search API key is not set (Settings > Search).")
        val url = HttpUrl.Builder().scheme("https").host("api.search.brave.com")
            .addPathSegments("res/v1/web/search")
            .addQueryParameter("q", q).addQueryParameter("count", limit.coerceIn(1, 20).toString()).build()
        val req = Request.Builder().url(url)
            .header("Accept", "application/json")
            .header("X-Subscription-Token", key).build()
        val resp = http.newCall(req).await()
        resp.use { r ->
            val txt = withContext(Dispatchers.IO) { r.body?.string().orEmpty() }
            if (!r.isSuccessful) throw WebException("Brave HTTP ${r.code}: ${txt.take(200)}")
            return json.parseToJsonElement(txt).jsonObject["web"].asObj()?.get("results").asArr().orEmpty().mapNotNull { e ->
                val o = e.asObj() ?: return@mapNotNull null
                val u = o["url"].str() ?: return@mapNotNull null
                val desc = Jsoup.parse(o["description"].str().orEmpty()).text()
                SearchResult(o["title"].str() ?: u, u, desc.take(400))
            }
        }
    }

    private suspend fun duckDuckGo(q: String, limit: Int): List<SearchResult> {
        val url = HttpUrl.Builder().scheme("https").host("html.duckduckgo.com")
            .addPathSegments("html/").addQueryParameter("q", q).build()
        val req = Request.Builder().url(url)
            .header("User-Agent", WebReader.UA)
            .header("Accept-Language", "en-US,en;q=0.9").build()
        val resp = http.newCall(req).await()
        resp.use { r ->
            val html = withContext(Dispatchers.IO) { r.body?.string().orEmpty() }
            if (r.code == 202 || r.code == 403 || r.code == 429) {
                throw WebException("DuckDuckGo refused automated search (HTTP ${r.code}). Set a Tavily or Brave key in Settings > Search.")
            }
            if (!r.isSuccessful) throw WebException("DuckDuckGo HTTP ${r.code}")
            val out = withContext(Dispatchers.Default) {
                val doc = Jsoup.parse(html)
                doc.select("div.result").mapNotNull { div ->
                    val a = div.selectFirst("a.result__a") ?: return@mapNotNull null
                    val href = a.attr("href")
                    val target = resolveDdg(href) ?: return@mapNotNull null
                    SearchResult(a.text(), target, div.selectFirst(".result__snippet")?.text().orEmpty())
                }
            }
            if (out.isEmpty() && html.contains("anomaly", true)) {
                throw WebException("DuckDuckGo showed a bot check. Set a Tavily or Brave key in Settings > Search.")
            }
            return out.take(limit)
        }
    }

    private fun resolveDdg(href: String): String? {
        val full = when {
            href.startsWith("//") -> "https:$href"
            href.startsWith("http") -> href
            else -> return null
        }
        val u = full.toHttpUrlOrNull() ?: return null
        if (u.host.endsWith("duckduckgo.com")) return u.queryParameter("uddg")
        return full
    }
}
