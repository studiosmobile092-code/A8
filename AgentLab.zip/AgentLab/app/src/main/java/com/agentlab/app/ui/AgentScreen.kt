package com.agentlab.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.agentlab.app.agent.pct
import com.agentlab.app.container
import com.agentlab.app.data.GitTaskEntity
import com.agentlab.app.data.ImprovementEntity
import com.agentlab.app.data.TestQuestionEntity
import kotlinx.coroutines.launch

@Composable
fun AgentScreen() {
    var tab by rememberSaveable { mutableStateOf(0) }
    val names = listOf("Run", "Changes", "Tests", "GitHub")
    Column(Modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = tab) {
            names.forEachIndexed { i, n -> Tab(selected = tab == i, onClick = { tab = i }, text = { Text(n) }) }
        }
        when (tab) {
            0 -> RunTab()
            1 -> ChangesTab()
            2 -> TestsTab()
            else -> GitHubTab()
        }
    }
}

// ---------------------------------------------------------------- RUN

@Composable
private fun RunTab() {
    val ctx = LocalContext.current
    val c = ctx.container
    val running by c.agent.running.collectAsState()
    val status by c.agent.status.collectAsState()
    val tokens by c.settings.tokensToday.collectAsState()
    val budget by c.settings.flow.collectAsState()
    val logs by c.db.logs().observeRecent(400).collectAsState(emptyList())
    val list = rememberLazyListState()
    val scope = rememberCoroutineScope()
    LaunchedEffect(logs.size) { if (logs.isNotEmpty()) list.scrollToItem(logs.size - 1) }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Button(onClick = { c.agent.start(ctx) }, enabled = !running) { Icon(Icons.Filled.PlayArrow, null); Text("RUN") }
            Button(
                onClick = { c.agent.stop() }, enabled = running,
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error, contentColor = MaterialTheme.colorScheme.onError)
            ) { Icon(Icons.Filled.Stop, null); Text("STOP") }
            Text(if (running) "Status: $status" else "Idle", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(Modifier.weight(1f), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = { scope.launch { c.db.logs().clear() } }) { Text("Clear log") }
            }
        }
        if (running) LinearProgressIndicator(Modifier.fillMaxWidth())
        Text(
            "Tokens today: $tokens / ${budget.dailyTokenBudget}",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Card(Modifier.weight(1f).fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
            LazyColumn(Modifier.fillMaxSize().padding(10.dp), state = list) {
                if (logs.isEmpty()) item { Text("The activity log appears here when the agent runs.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
                items(logs, key = { it.id }) { l ->
                    val color = when (l.level) {
                        "PHASE" -> MaterialTheme.colorScheme.primary
                        "WARN" -> MaterialTheme.colorScheme.tertiary
                        "ERROR" -> MaterialTheme.colorScheme.error
                        else -> MaterialTheme.colorScheme.onSurface
                    }
                    Text(
                        l.message, color = color, fontFamily = FontFamily.Monospace,
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = if (l.level == "PHASE") FontWeight.Bold else FontWeight.Normal,
                        modifier = Modifier.padding(vertical = 2.dp)
                    )
                }
            }
        }
    }
}

// ---------------------------------------------------------------- CHANGES

@Composable
private fun ChangesTab() {
    val c = LocalContext.current.container
    val items by c.db.improvements().observeAll().collectAsState(emptyList())
    val settings by c.settings.flow.collectAsState()
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val pending = items.filter { it.status == "PENDING" }
    val rest = items.filter { it.status != "PENDING" }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Auto-approve changes that improved the score", style = MaterialTheme.typography.bodyMedium)
                    Text("Off by default. Changes that did not improve are always rolled back.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(settings.autoApprove, { v -> c.settings.update { it.copy(autoApprove = v) } })
            }
            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        }
        item { Text("Waiting for approval (${pending.size})", style = MaterialTheme.typography.titleMedium) }
        if (pending.isEmpty()) item { Text("Nothing waiting.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        items(pending, key = { "p${it.id}" }) { imp ->
            ChangeCard(imp, showDiff = true) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { scope.launch { error = c.applier.apply(imp.id, false) } }) { Text("Approve") }
                    OutlinedButton(onClick = { scope.launch { c.applier.reject(imp.id) } }) { Text("Reject") }
                }
            }
        }
        item { Text("History", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 8.dp)) }
        if (rest.isEmpty()) item { Text("No changes tested yet.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        items(rest, key = { "h${it.id}" }) { imp -> ChangeCard(imp, showDiff = false) {} }
    }
}

@Composable
private fun ChangeCard(imp: ImprovementEntity, showDiff: Boolean, actions: @Composable () -> Unit) {
    var open by remember { mutableStateOf(showDiff) }
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("${imp.kind}: ${imp.target}", style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                Text(imp.status.replace('_', ' '), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
            }
            Text(imp.reason, style = MaterialTheme.typography.bodyMedium)
            Text(
                "Before ${pct(imp.scoreBefore)}  →  After ${pct(imp.scoreAfter)}  ·  ${fmtDate(imp.createdAt)}",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (!showDiff) TextButton(onClick = { open = !open }) { Text(if (open) "Hide diff" else "Show diff") }
            if (open) DiffView(imp.oldText, imp.newText)
            actions()
        }
    }
}

// ---------------------------------------------------------------- TESTS

@Composable
private fun TestsTab() {
    val c = LocalContext.current.container
    val qs by c.db.testQuestions().observeAll().collectAsState(emptyList())
    var editing by remember { mutableStateOf<TestQuestionEntity?>(null) }
    var adding by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Test questions", style = MaterialTheme.typography.titleMedium)
                Text("Your own questions plus ones the agent generates from what it learned. The optional reference answer is used for grading; otherwise the knowledge base is.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Button(onClick = { adding = true }) { Icon(Icons.Filled.Add, null); Text("Add") }
        }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(qs, key = { it.id }) { q ->
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
                    Row(Modifier.padding(start = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f).padding(vertical = 8.dp)) {
                            Text(q.question, style = MaterialTheme.typography.bodyMedium)
                            if (q.reference.isNotBlank()) Text("Reference: ${q.reference}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            if (q.generated) Text("generated", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                        }
                        IconButton(onClick = { editing = q }) { Icon(Icons.Filled.Edit, contentDescription = "Edit") }
                        IconButton(onClick = { scope.launch { c.db.testQuestions().delete(q) } }) { Icon(Icons.Filled.Delete, contentDescription = "Delete") }
                    }
                }
            }
        }
    }
    if (adding || editing != null) {
        val cur = editing
        var question by remember(cur) { mutableStateOf(cur?.question ?: "") }
        var ref by remember(cur) { mutableStateOf(cur?.reference ?: "") }
        AlertDialog(
            onDismissRequest = { adding = false; editing = null },
            title = { Text(if (cur == null) "Add question" else "Edit question") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(question, { question = it }, label = { Text("Question") }, minLines = 2)
                    OutlinedTextField(ref, { ref = it }, label = { Text("Reference answer (optional)") }, minLines = 2)
                }
            },
            confirmButton = {
                TextButton(enabled = question.isNotBlank(), onClick = {
                    scope.launch {
                        if (cur == null) c.db.testQuestions().insert(TestQuestionEntity(question = question.trim(), reference = ref.trim()))
                        else c.db.testQuestions().update(cur.copy(question = question.trim(), reference = ref.trim(), generated = false))
                    }
                    adding = false; editing = null
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { adding = false; editing = null }) { Text("Cancel") } }
        )
    }
}

// ---------------------------------------------------------------- GITHUB

@Composable
private fun GitHubTab() {
    val c = LocalContext.current.container
    val tasks by c.db.gitTasks().observeAll().collectAsState(emptyList())
    val busy by c.selfEditor.busy.collectAsState()
    val uri = LocalUriHandler.current
    var adding by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Self-rewrite via GitHub", style = MaterialTheme.typography.titleMedium)
                Text("Describe a change to the app. The agent edits its source on a new branch, opens a pull request, watches the build, and fixes build errors (up to 3 fix pushes). It never pushes to main; you merge.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Button(onClick = { adding = true }) { Icon(Icons.Filled.Add, null); Text("Task") }
        }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(tasks, key = { it.id }) { t -> TaskCard(t, busy, uri::openUri) }
        }
    }
    if (adding) {
        var title by remember { mutableStateOf("") }
        var desc by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { adding = false },
            title = { Text("New change request") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(title, { title = it }, label = { Text("Title") }, singleLine = true)
                    OutlinedTextField(desc, { desc = it }, label = { Text("What should change?") }, minLines = 4)
                }
            },
            confirmButton = {
                TextButton(enabled = title.isNotBlank() && desc.isNotBlank(), onClick = {
                    scope.launch { c.selfEditor.createTask(title, desc) }
                    adding = false
                }) { Text("Create") }
            },
            dismissButton = { TextButton(onClick = { adding = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun TaskCard(t: GitTaskEntity, busy: Boolean, open: (String) -> Unit) {
    val c = LocalContext.current.container
    val scope = rememberCoroutineScope()
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row {
                Text(t.title, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                Text(t.status, style = MaterialTheme.typography.labelMedium, color = if (t.status == "FAILED") MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)
            }
            Text(t.description, style = MaterialTheme.typography.bodySmall, maxLines = 3)
            if (t.branch.isNotBlank()) Text("Branch: ${t.branch}", style = MaterialTheme.typography.bodySmall, fontFamily = FontFamily.Monospace)
            if (t.buildStatus.isNotBlank()) Text("Build: ${t.buildStatus}  ·  fix attempts: ${t.attempts}/3", style = MaterialTheme.typography.bodySmall)
            if (t.lastError.isNotBlank()) Text(t.lastError, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                if (t.status == "NEW") TextButton(enabled = !busy, onClick = { c.selfEditor.start(t.id) }) { Text("Start") }
                if (t.status == "FAILED") TextButton(enabled = !busy, onClick = {
                    scope.launch {
                        c.db.gitTasks().update(t.copy(branch = "", prNumber = 0, prUrl = "", status = "NEW", buildStatus = "", attempts = 0, lastError = ""))
                        c.selfEditor.start(t.id)
                    }
                }) { Text("Retry") }
                if (t.status == "WORKING" || t.status == "PR_OPEN") TextButton(enabled = busy, onClick = { c.selfEditor.cancel() }) { Text("Cancel") }
                if (t.branch.isNotBlank()) TextButton(onClick = { scope.launch { c.selfEditor.refresh(t.id) } }) { Text("Refresh") }
                if (t.prUrl.isNotBlank()) TextButton(onClick = { open(t.prUrl) }) { Text("Pull request") }
                if (t.artifactUrl.isNotBlank()) TextButton(onClick = { open(t.artifactUrl) }) { Text("Download APK") }
                else if (t.buildUrl.isNotBlank()) TextButton(onClick = { open(t.buildUrl) }) { Text("Build log") }
            }
        }
    }
}
