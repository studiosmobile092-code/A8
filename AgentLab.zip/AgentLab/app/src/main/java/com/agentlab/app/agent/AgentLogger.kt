package com.agentlab.app.agent

import com.agentlab.app.data.AppDb
import com.agentlab.app.data.LogEntity

class AgentLogger(private val db: AppDb, val runId: Long) {
    suspend fun info(msg: String) = db.logs().insert(LogEntity(runId = runId, level = "INFO", message = msg))
    suspend fun warn(msg: String) = db.logs().insert(LogEntity(runId = runId, level = "WARN", message = msg))
    suspend fun error(msg: String) = db.logs().insert(LogEntity(runId = runId, level = "ERROR", message = msg))
    suspend fun phase(msg: String) = db.logs().insert(LogEntity(runId = runId, level = "PHASE", message = msg))
}

fun extractJsonArray(t: String): String? {
    val s = t.indexOf('[')
    val e = t.lastIndexOf(']')
    return if (s >= 0 && e > s) t.substring(s, e + 1) else null
}

fun extractJsonObject(t: String): String? {
    val s = t.indexOf('{')
    val e = t.lastIndexOf('}')
    return if (s >= 0 && e > s) t.substring(s, e + 1) else null
}
