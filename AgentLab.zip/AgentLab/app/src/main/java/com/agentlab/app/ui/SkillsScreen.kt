package com.agentlab.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.agentlab.app.agent.SkillWriter
import com.agentlab.app.container
import com.agentlab.app.data.SkillEntity
import com.agentlab.app.skills.SkillManager
import kotlinx.coroutines.launch

private const val TEMPLATE = "function run(input) {\n  // input is the parsed JSON object passed to the skill\n  return { echo: input };\n}\n"

@Composable
fun SkillsScreen() {
    val c = LocalContext.current.container
    val skills by c.db.skills().observeAll().collectAsState(emptyList())
    var selected by rememberSaveable { mutableStateOf<String?>(null) }
    val sel = skills.firstOrNull { it.name == selected }
    if (sel != null) SkillEditor(sel, onBack = { selected = null }) else SkillList(skills, onOpen = { selected = it })
}

@Composable
private fun SkillList(skills: List<SkillEntity>, onOpen: (String) -> Unit) {
    val c = LocalContext.current.container
    val scope = rememberCoroutineScope()
    var newDialog by remember { mutableStateOf(false) }
    var aiDialog by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Skills", style = MaterialTheme.typography.titleLarge)
                Text("JavaScript run in a sandbox, hot-loaded, versioned", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            OutlinedButton(onClick = { aiDialog = true }) { Icon(Icons.Filled.AutoAwesome, null); Text("AI skill") }
            Button(onClick = { newDialog = true }, modifier = Modifier.padding(start = 8.dp)) { Icon(Icons.Filled.Add, null); Text("New") }
        }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(skills, key = { it.name }) { s ->
                Card(
                    onClick = { onOpen(s.name) },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)
                ) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("${s.name}  ·  v${s.version}", style = MaterialTheme.typography.titleSmall)
                            Text(s.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(s.enabled, { v -> scope.launch { c.skills.setEnabled(s.name, v) } })
                    }
                }
            }
        }
    }
    if (newDialog) NameDialog("New skill", "Create", false, { newDialog = false }) { name, desc, _ ->
        scope.launch {
            val r = c.skills.save(name, desc.ifBlank { "Custom skill" }, TEMPLATE, "Created")
            if (r.ok) onOpen(name)
        }
        newDialog = false
    }
    if (aiDialog) {
        var busy by remember { mutableStateOf(false) }
        var err by remember { mutableStateOf<String?>(null) }
        NameDialog("Ask the AI to write a skill", "Write", true, { aiDialog = false }, busy = busy, error = err) { name, desc, request ->
            busy = true; err = null
            c.scope.launch {
                val r = try { SkillWriter.write(c, name, desc.ifBlank { request.take(120) }, request) } catch (e: Exception) { com.agentlab.app.skills.SaveResult(false, e.message) }
                busy = false
                if (r.ok) { aiDialog = false; onOpen(name) } else err = r.error
            }
        }
    }
}

@Composable
private fun NameDialog(
    title: String, confirm: String, withRequest: Boolean, onDismiss: () -> Unit,
    busy: Boolean = false, error: String? = null, onOk: (String, String, String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    var req by remember { mutableStateOf("") }
    val nameOk = SkillManager.NAME_RE.matches(name)
    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it.lowercase() }, label = { Text("Name (a-z, 0-9, _)") }, singleLine = true, isError = name.isNotEmpty() && !nameOk)
                OutlinedTextField(desc, { desc = it }, label = { Text("Description") })
                if (withRequest) OutlinedTextField(req, { req = it }, label = { Text("What should it do?") }, minLines = 3)
                if (busy) Row(verticalAlignment = Alignment.CenterVertically) { CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp); Text("  Writing and testing…") }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = { TextButton(enabled = nameOk && !busy && (!withRequest || req.isNotBlank()), onClick = { onOk(name, desc, req) }) { Text(confirm) } },
        dismissButton = { TextButton(enabled = !busy, onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun SkillEditor(skill: SkillEntity, onBack: () -> Unit) {
    val c = LocalContext.current.container
    val scope = rememberCoroutineScope()
    var code by remember(skill.name, skill.version) { mutableStateOf(skill.code) }
    var message by remember { mutableStateOf<String?>(null) }
    var history by remember { mutableStateOf(false) }
    var runDialog by remember { mutableStateOf(false) }
    var aiDialog by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    val dirty = code != skill.code

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
            Column(Modifier.weight(1f)) {
                Text(skill.name, style = MaterialTheme.typography.titleMedium)
                Text("v${skill.version}" + if (dirty) "  ·  unsaved changes" else "", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            IconButton(onClick = { aiDialog = true }) { Icon(Icons.Filled.AutoAwesome, contentDescription = "Improve with AI") }
            IconButton(onClick = { history = true }) { Icon(Icons.Filled.History, contentDescription = "History") }
            IconButton(onClick = { runDialog = true }) { Icon(Icons.Filled.PlayArrow, contentDescription = "Test run") }
            IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Filled.Delete, contentDescription = "Delete") }
            Button(enabled = dirty, onClick = {
                scope.launch {
                    val r = c.skills.save(skill.name, skill.description, code, "Manual edit")
                    message = if (r.ok) "Saved as v${r.version}" else r.error
                }
            }) { Icon(Icons.Filled.Save, null); Text("Save") }
        }
        message?.let { Text(it, modifier = Modifier.padding(horizontal = 16.dp), color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall) }
        CodeEditor(code, { code = it }, Modifier.weight(1f).fillMaxWidth())
    }

    if (history) HistoryDialog(skill, onClose = { history = false }, onView = { code = it; history = false })
    if (runDialog) RunDialog(skill, onClose = { runDialog = false })
    if (aiDialog) {
        var instruction by remember { mutableStateOf("") }
        var busy by remember { mutableStateOf(false) }
        var err by remember { mutableStateOf<String?>(null) }
        AlertDialog(
            onDismissRequest = { if (!busy) aiDialog = false },
            title = { Text("Improve with AI") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(instruction, { instruction = it }, label = { Text("What should change?") }, minLines = 3)
                    if (busy) Text("Writing and testing…")
                    err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                }
            },
            confirmButton = {
                TextButton(enabled = instruction.isNotBlank() && !busy, onClick = {
                    busy = true; err = null
                    c.scope.launch {
                        val r = try { SkillWriter.write(c, skill.name, skill.description, instruction, code) } catch (e: Exception) { com.agentlab.app.skills.SaveResult(false, e.message) }
                        busy = false
                        if (r.ok) { aiDialog = false; message = "AI saved v${r.version}. Use History to roll back." } else err = r.error
                    }
                }) { Text("Apply") }
            },
            dismissButton = { TextButton(enabled = !busy, onClick = { aiDialog = false }) { Text("Cancel") } }
        )
    }
    if (confirmDelete) AlertDialog(
        onDismissRequest = { confirmDelete = false },
        title = { Text("Delete ${skill.name}?") },
        text = { Text("All versions are removed.") },
        confirmButton = { TextButton(onClick = { scope.launch { c.skills.delete(skill.name) }; confirmDelete = false; onBack() }) { Text("Delete") } },
        dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } }
    )
}

@Composable
private fun HistoryDialog(skill: SkillEntity, onClose: () -> Unit, onView: (String) -> Unit) {
    val c = LocalContext.current.container
    val scope = rememberCoroutineScope()
    val versions by c.db.skills().observeVersions(skill.name).collectAsState(emptyList())
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Version history") },
        text = {
            LazyColumn(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(versions, key = { it.id }) { v ->
                    Column {
                        Text("v${v.version}" + if (v.version == skill.version) " (current)" else "", style = MaterialTheme.typography.titleSmall)
                        Text("${fmtDate(v.createdAt)} · ${v.note}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Row {
                            TextButton(onClick = { onView(v.code) }) { Text("View") }
                            if (v.version != skill.version) TextButton(onClick = {
                                scope.launch { c.skills.rollback(skill.name, v.version, "Manual rollback") }
                                onClose()
                            }) { Text("Roll back") }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("Close") } }
    )
}

@Composable
private fun RunDialog(skill: SkillEntity, onClose: () -> Unit) {
    val c = LocalContext.current.container
    var input by remember { mutableStateOf("{}") }
    var output by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = { if (!busy) onClose() },
        title = { Text("Test run ${skill.name}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(input, { input = it }, label = { Text("Input JSON") }, minLines = 2)
                if (busy) CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.dp)
                output?.let { CodeBlock("output", it) }
            }
        },
        confirmButton = {
            TextButton(enabled = !busy, onClick = {
                busy = true; output = null
                c.scope.launch {
                    val (res, note) = c.skills.run(skill.name, input)
                    output = (if (res.ok) res.value else "ERROR: ${res.value}") + (note?.let { "\n\n$it" } ?: "")
                    busy = false
                }
            }) { Text("Run") }
        },
        dismissButton = { TextButton(enabled = !busy, onClick = onClose) { Text("Close") } }
    )
}
