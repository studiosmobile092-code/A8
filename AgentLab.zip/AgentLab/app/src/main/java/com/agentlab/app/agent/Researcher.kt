package com.agentlab.app.agent

import com.agentlab.app.Container
import com.agentlab.app.llm.BudgetExceededException
import com.agentlab.app.llm.LlmMessage
import com.agentlab.app.web.Page
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import org.json.JSONArray

/** RESEARCH + LEARN phases: read sources, search topics, follow useful links, extract and store facts. */
class Researcher(private val c: Container, private val log: AgentLogger) {
    /** A few pages from this run, kept so research-strategy changes can be tested on real content. */
    val samplePages = mutableListOf<Page>()

    companion object {
        const val EXTRACT_SYSTEM =
            "You extract knowledge from a web page. Extract 3-8 distinct, self-contained facts that are stated in the text. " +
                "Skip ads, navigation, cookie notices and boilerplate. Never invent anything.\n" +
                "Return ONLY a JSON array, no markdown fences: " +
                "[{\"title\":\"short title\",\"summary\":\"2-4 sentence fact with concrete details\",\"quality\":0.0}] " +
                "where quality (0 to 1) rates how reliable, specific and useful the fact is."
    }

    /** Reads all enabled sources, or only [onlyId] (even if disabled) when given. */
    suspend fun run(onlyId: Long? = null): Int {
        val s = c.settings.current
        val sources = if (onlyId == null) c.db.sources().getEnabled() else c.db.sources().getAll().filter { it.id == onlyId }
        if (sources.isEmpty()) {
            log.warn("No enabled sources. Add URLs, topics or queries in the Sources tab.")
            return 0
        }
        val queue = ArrayDeque<Triple<String, Int, Long>>() // url, depth, source id
        val errors = HashMap<Long, String>()
        for (src in sources) {
            currentCoroutineContext().ensureActive()
            if (src.type == "URL") {
                queue.add(Triple(src.value, 0, src.id))
            } else {
                try {
                    log.info("Searching: ${src.value}")
                    val res = c.search.search(src.value, 5)
                    if (res.isEmpty()) errors[src.id] = "Search returned no results"
                    res.forEach { queue.add(Triple(it.url, 0, src.id)) }
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    errors[src.id] = e.message ?: "search failed"
                    log.warn("Search failed for '${src.value}': ${e.message}")
                }
            }
        }
        val visited = HashSet<String>()
        val addedBySource = HashMap<Long, Int>()
        val readBySource = HashMap<Long, Int>()
        var read = 0
        var added = 0
        while (queue.isNotEmpty() && read < s.maxPagesPerRun) {
            currentCoroutineContext().ensureActive()
            val (url, depth, sid) = queue.removeFirst()
            if (!visited.add(url.substringBefore('#').trimEnd('/'))) continue
            log.info("Reading ($read/${s.maxPagesPerRun}) $url")
            try {
                val page = c.web.read(url)
                read++
                readBySource.merge(sid, 1, Int::plus)
                if (samplePages.size < 3) samplePages.add(page)
                val n = learn(page, s.researchStrategy, null)
                added += n
                addedBySource.merge(sid, n, Int::plus)
                log.info("  +$n new entries from ${page.title.take(60)}")
                if (depth < s.maxLinkDepth && page.links.isNotEmpty()) {
                    for (l in chooseLinks(page, s.researchStrategy)) queue.add(Triple(l, depth + 1, sid))
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: BudgetExceededException) {
                log.error(e.message ?: "Budget exceeded")
                break
            } catch (e: Exception) {
                log.warn("Failed $url: ${e.message}")
                if (depth == 0) errors[sid] = e.message ?: "read failed"
            }
        }
        val now = System.currentTimeMillis()
        for (src in sources) {
            val touched = readBySource.containsKey(src.id) || errors.containsKey(src.id)
            if (!touched) continue
            c.db.sources().update(
                src.copy(
                    lastRead = now,
                    entryCount = src.entryCount + (addedBySource[src.id] ?: 0),
                    lastError = if (readBySource.containsKey(src.id)) null else errors[src.id]
                )
            )
        }
        return added
    }

    /** Extracts facts from a page and stores them. Returns the number of new entries. Ids go to [collect] if given. */
    suspend fun learn(page: Page, strategy: String, collect: MutableList<Long>?): Int {
        var n = 0
        for (chunk in page.text.chunked(10_000).take(3)) {
            currentCoroutineContext().ensureActive()
            val out = c.llm.complete(
                listOf(LlmMessage("user", "SOURCE: ${page.url}\nTITLE: ${page.title}\n\nTEXT:\n$chunk")),
                system = EXTRACT_SYSTEM + "\n\nRESEARCH STRATEGY:\n" + strategy,
                temperature = 0.2f, maxTokens = 2000
            )
            val json = extractJsonArray(out) ?: continue
            val arr = try { JSONArray(json) } catch (e: Exception) { continue }
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val title = o.optString("title").ifBlank { page.title }
                val summary = o.optString("summary")
                val id = c.knowledge.add(title, summary, page.url, o.optDouble("quality", 0.5).toFloat())
                if (id != null) { n++; collect?.add(id) }
            }
        }
        return n
    }

    private suspend fun chooseLinks(page: Page, strategy: String): List<String> {
        val links = page.links.filter { it.startsWith("http") }.take(40)
        if (links.isEmpty()) return emptyList()
        return try {
            val out = c.llm.complete(
                listOf(LlmMessage("user", "PAGE: ${page.title}\nCANDIDATE LINKS:\n" + links.joinToString("\n"))),
                system = "Pick at most 3 links from the list that are most worth reading to learn more, following this strategy:\n$strategy\n" +
                    "Return ONLY a JSON array of URLs copied exactly from the list, or [] if none are useful.",
                temperature = 0.1f, maxTokens = 300
            )
            val arr = JSONArray(extractJsonArray(out) ?: return emptyList())
            (0 until arr.length()).map { arr.optString(it) }.filter { it in links }.take(3)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            emptyList()
        }
    }
}
