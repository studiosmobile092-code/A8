package com.agentlab.app.web

import android.content.Context
import com.agentlab.app.data.SettingsStore
import com.agentlab.app.llm.asArr
import com.agentlab.app.llm.asObj
import com.agentlab.app.llm.await
import com.agentlab.app.llm.str
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonObject
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.ResponseBody
import org.jsoup.Jsoup
import org.jsoup.nodes.Element
import org.jsoup.nodes.Node
import org.jsoup.nodes.TextNode
import java.net.URI
import java.net.URLEncoder

class WebException(message: String) : Exception(message)

data class Page(
    val url: String,
    val title: String,
    val text: String,
    val links: List<String>,
    val kind: String // html | pdf | text | github | github-file | youtube
)

class WebReader(
    private val context: Context,
    private val http: OkHttpClient,
    private val settings: SettingsStore
) {
    private val json = Json { ignoreUnknownKeys = true }
    @Volatile private var pdfReady = false

    companion object {
        const val UA = "Mozilla/5.0 (Linux; Android 14; Pixel Tablet) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"
        const val MAX_CHARS = 80_000
        private const val MAX_HTML = 4_000_000
        private const val MAX_PDF = 20_000_000
        private val BLOCK = setOf(
            "p", "div", "section", "article", "main", "ul", "ol", "li", "table", "tr", "blockquote",
            "h1", "h2", "h3", "h4", "h5", "h6", "dl", "dt", "dd", "figure", "figcaption", "details", "summary"
        )
    }

    fun normalizeUrl(raw: String): String {
        val t = raw.trim()
        if (t.isEmpty()) throw WebException("Empty URL")
        val withScheme = if (t.startsWith("http://") || t.startsWith("https://")) t else "https://$t"
        try {
            val u = URI(withScheme)
            if (u.host.isNullOrBlank()) throw WebException("Invalid URL: $raw")
        } catch (e: WebException) {
            throw e
        } catch (e: Exception) {
            throw WebException("Invalid URL: $raw")
        }
        return withScheme
    }

    suspend fun read(rawUrl: String): Page {
        val url = normalizeUrl(rawUrl)
        val host = URI(url).host.lowercase().removePrefix("www.")
        return when {
            host == "github.com" -> readGithub(url) ?: readGeneric(url)
            host == "youtube.com" || host == "m.youtube.com" || host == "youtu.be" -> readYoutube(url)
            else -> readGeneric(url)
        }
    }

    // ---------------- generic ----------------

    private fun readLimited(body: ResponseBody, max: Int): ByteArray {
        val src = body.source()
        src.request(max.toLong() + 1)
        val n = minOf(src.buffer.size, max.toLong())
        return src.buffer.readByteArray(n)
    }

    private suspend fun readGeneric(url: String): Page {
        val req = Request.Builder().url(url)
            .header("User-Agent", UA)
            .header("Accept", "text/html,application/xhtml+xml,application/pdf,text/plain;q=0.9,*/*;q=0.5")
            .header("Accept-Language", "en-US,en;q=0.9")
            .build()
        val resp = http.newCall(req).await()
        resp.use { r ->
            if (!r.isSuccessful) throw WebException("HTTP ${r.code} for $url")
            val body = r.body ?: throw WebException("Empty response for $url")
            val ctype = (r.header("Content-Type") ?: "").lowercase()
            val finalUrl = r.request.url.toString()
            val isPdf = ctype.contains("pdf") || finalUrl.substringBefore('?').lowercase().endsWith(".pdf")
            val bytes = withContext(Dispatchers.IO) { readLimited(body, if (isPdf) MAX_PDF else MAX_HTML) }
            if (isPdf || (bytes.size > 4 && String(bytes, 0, 4, Charsets.ISO_8859_1) == "%PDF")) {
                return readPdf(finalUrl, bytes)
            }
            val charset = body.contentType()?.charset(Charsets.UTF_8) ?: Charsets.UTF_8
            val text = String(bytes, charset)
            val looksHtml = ctype.contains("html") || ctype.contains("xml") || text.trimStart().startsWith("<")
            if (!looksHtml) {
                val clean = text.trim()
                if (clean.isEmpty()) throw WebException("No readable text at $url")
                return Page(finalUrl, finalUrl.substringAfterLast('/'), clean.take(MAX_CHARS), extractLinks(clean), "text")
            }
            return parseHtml(finalUrl, text)
        }
    }

    private suspend fun parseHtml(url: String, html: String): Page = withContext(Dispatchers.Default) {
        val doc = Jsoup.parse(html, url)
        val title = doc.title().ifBlank { url }
        val links = doc.select("a[href]").map { it.absUrl("href").substringBefore('#') }
            .filter { it.startsWith("http://") || it.startsWith("https://") }
            .distinct().take(300)
        doc.select("script,style,noscript,nav,footer,header,aside,form,svg,iframe,button,dialog").remove()
        val main = doc.selectFirst("article") ?: doc.selectFirst("main") ?: doc.selectFirst("[role=main]") ?: doc.body()
        val text = if (main == null) "" else renderText(main)
        if (text.length < 40) throw WebException("No readable text at $url (page may need JavaScript or a login)")
        Page(url, title, text.take(MAX_CHARS), links, "html")
    }

    private fun renderText(root: Element): String {
        val sb = StringBuilder()
        fun walk(n: Node) {
            if (n is TextNode) {
                val t = n.text()
                if (t.isNotBlank()) sb.append(t)
                return
            }
            if (n !is Element) return
            val tag = n.tagName().lowercase()
            if (tag == "pre") {
                sb.append("\n```\n").append(n.wholeText().trimEnd()).append("\n```\n")
                return
            }
            if (tag == "br") sb.append("\n")
            val isBlock = tag in BLOCK
            if (tag.length == 2 && tag[0] == 'h' && tag[1] in '1'..'6') {
                sb.append("\n\n").append("#".repeat(tag[1] - '0')).append(' ')
            } else if (tag == "li") {
                sb.append("\n- ")
            } else if (isBlock) {
                sb.append("\n")
            }
            for (c in n.childNodes()) walk(c)
            if (isBlock) sb.append("\n")
        }
        walk(root)
        return sb.toString().replace(Regex("[ \\t]+\\n"), "\n").replace(Regex("\\n{3,}"), "\n\n").trim()
    }

    private fun extractLinks(text: String): List<String> =
        Regex("https?://[^\\s)>\\]\"'<]+").findAll(text).map { it.value.trimEnd('.', ',', ';') }.distinct().take(60).toList()

    // ---------------- PDF ----------------

    private suspend fun readPdf(url: String, bytes: ByteArray): Page = withContext(Dispatchers.IO) {
        if (!pdfReady) {
            PDFBoxResourceLoader.init(context.applicationContext)
            pdfReady = true
        }
        val doc = try {
            PDDocument.load(bytes)
        } catch (e: Exception) {
            throw WebException("Could not open PDF: ${e.message}")
        }
        try {
            val stripper = PDFTextStripper()
            stripper.startPage = 1
            stripper.endPage = minOf(doc.numberOfPages, 80)
            val text = stripper.getText(doc).replace(Regex("\\n{3,}"), "\n\n").trim()
            if (text.length < 40) throw WebException("PDF has no extractable text (scanned image?)")
            val title = doc.documentInformation?.title?.takeIf { it.isNotBlank() } ?: url.substringAfterLast('/')
            Page(url, title, text.take(MAX_CHARS), extractLinks(text), "pdf")
        } finally {
            doc.close()
        }
    }

    // ---------------- GitHub ----------------

    private fun ghRequest(url: String, accept: String = "application/vnd.github+json"): Request {
        val b = Request.Builder().url(url)
            .header("Accept", accept)
            .header("X-GitHub-Api-Version", "2022-11-28")
            .header("User-Agent", "AgentLab")
        val token = settings.current.githubToken
        if (token.isNotBlank()) b.header("Authorization", "Bearer $token")
        return b.build()
    }

    private suspend fun ghGet(url: String, accept: String = "application/vnd.github+json"): String? {
        val resp = http.newCall(ghRequest(url, accept)).await()
        resp.use { r ->
            if (!r.isSuccessful) return null
            return withContext(Dispatchers.IO) { r.body?.string() }
        }
    }

    private suspend fun readGithub(url: String): Page? {
        val segs = URI(url).path.split('/').filter { it.isNotEmpty() }
        if (segs.size < 2) return null
        val owner = segs[0]
        val repo = segs[1].removeSuffix(".git")
        val mode = segs.getOrNull(2)
        if (mode == "blob" && segs.size >= 5) {
            val ref = segs[3]
            val path = segs.drop(4).joinToString("/")
            val raw = "https://raw.githubusercontent.com/$owner/$repo/$ref/$path"
            val text = ghGet(raw, "text/plain") ?: throw WebException("Could not read $url")
            return Page(url, "$owner/$repo/$path", text.take(MAX_CHARS), extractLinks(text), "github-file")
        }
        if (mode != null && mode != "tree") return null // issues, pulls, etc. -> generic HTML
        val info = ghGet("https://api.github.com/repos/$owner/$repo")
            ?: throw WebException("GitHub repo $owner/$repo not found or rate-limited (add a GitHub token in Settings)")
        val infoObj = json.parseToJsonElement(info).jsonObject
        val branch = (if (mode == "tree") segs.getOrNull(3) else null) ?: infoObj["default_branch"].str() ?: "main"
        val sb = StringBuilder()
        sb.append("# $owner/$repo\n")
        infoObj["description"].str()?.let { sb.append(it).append("\n") }
        infoObj["homepage"].str()?.takeIf { it.isNotBlank() }?.let { sb.append("Homepage: $it\n") }
        val topics = infoObj["topics"].asArr()?.mapNotNull { it.str() }.orEmpty()
        if (topics.isNotEmpty()) sb.append("Topics: ${topics.joinToString(", ")}\n")
        infoObj["language"].str()?.let { sb.append("Main language: $it\n") }

        val readme = ghGet("https://api.github.com/repos/$owner/$repo/readme?ref=$branch", "application/vnd.github.raw")
        if (readme != null) sb.append("\n## README\n").append(readme.take(30_000)).append("\n")

        val tree = ghGet("https://api.github.com/repos/$owner/$repo/git/trees/$branch?recursive=1")
        val paths = if (tree != null) {
            json.parseToJsonElement(tree).jsonObject["tree"].asArr().orEmpty().mapNotNull { e ->
                val o = e.asObj() ?: return@mapNotNull null
                if (o["type"].str() == "blob") o["path"].str() else null
            }
        } else emptyList()
        if (paths.isNotEmpty()) {
            sb.append("\n## File tree (first 120 of ${paths.size})\n")
            paths.take(120).forEach { sb.append(it).append("\n") }
            val docRegex = Regex("(?i)^(docs?/.*\\.(md|rst|txt|adoc)|[^/]+\\.(md|rst)|package\\.json|pyproject\\.toml|Cargo\\.toml|go\\.mod|build\\.gradle(\\.kts)?|pom\\.xml)$")
            val wanted = paths.filter { docRegex.matches(it) && !it.equals("README.md", true) }.take(8)
            for (p in wanted) {
                val t = ghGet("https://raw.githubusercontent.com/$owner/$repo/$branch/$p", "text/plain") ?: continue
                sb.append("\n## $p\n").append(t.take(8_000)).append("\n")
                if (sb.length > MAX_CHARS) break
            }
        }
        if (readme == null && paths.isEmpty()) throw WebException("Nothing readable in GitHub repo $owner/$repo")
        val text = sb.toString().take(MAX_CHARS)
        return Page(url, "$owner/$repo", text, extractLinks(readme ?: ""), "github")
    }

    // ---------------- YouTube ----------------

    private fun videoId(url: String): String? {
        val u = URI(url)
        val host = u.host.lowercase().removePrefix("www.")
        if (host == "youtu.be") return u.path.trim('/').takeIf { it.isNotEmpty() }
        val q = (u.rawQuery ?: "").split('&').associate { it.substringBefore('=') to it.substringAfter('=', "") }
        q["v"]?.let { return it }
        val segs = u.path.split('/').filter { it.isNotEmpty() }
        if (segs.size >= 2 && (segs[0] == "shorts" || segs[0] == "embed" || segs[0] == "live")) return segs[1]
        return null
    }

    private fun extractJsonObject(s: String, from: Int): String? {
        val start = s.indexOf('{', from)
        if (start < 0) return null
        var depth = 0
        var inStr = false
        var esc = false
        for (i in start until s.length) {
            val c = s[i]
            if (inStr) {
                if (esc) esc = false else if (c == '\\') esc = true else if (c == '"') inStr = false
            } else {
                when (c) {
                    '"' -> inStr = true
                    '{' -> depth++
                    '}' -> { depth--; if (depth == 0) return s.substring(start, i + 1) }
                }
            }
        }
        return null
    }

    private suspend fun readYoutube(url: String): Page {
        val id = videoId(url) ?: throw WebException("Could not find a YouTube video id in $url")
        val watch = Request.Builder().url("https://www.youtube.com/watch?v=${URLEncoder.encode(id, "UTF-8")}&hl=en")
            .header("User-Agent", UA)
            .header("Accept-Language", "en-US,en;q=0.9")
            .header("Cookie", "CONSENT=YES+1; SOCS=CAI")
            .build()
        val html = http.newCall(watch).await().use { r ->
            if (!r.isSuccessful) throw WebException("YouTube returned HTTP ${r.code}")
            withContext(Dispatchers.IO) { r.body?.string().orEmpty() }
        }
        val marker = html.indexOf("ytInitialPlayerResponse")
        val playerJson = if (marker >= 0) extractJsonObject(html, marker) else null
            ?: throw WebException("Could not read YouTube player data (consent page or layout change)")
        val player = json.parseToJsonElement(playerJson ?: throw WebException("Could not read YouTube player data")).jsonObject
        val details = player["videoDetails"].asObj()
        val title = details?.get("title").str() ?: "YouTube video $id"
        val author = details?.get("author").str().orEmpty()
        val desc = details?.get("shortDescription").str().orEmpty()
        val tracks = player["captions"].asObj()?.get("playerCaptionsTracklistRenderer").asObj()
            ?.get("captionTracks").asArr().orEmpty().mapNotNull { it.asObj() }
        val track = tracks.firstOrNull { it["languageCode"].str()?.startsWith("en") == true && it["kind"].str() != "asr" }
            ?: tracks.firstOrNull { it["languageCode"].str()?.startsWith("en") == true }
            ?: tracks.firstOrNull()
        val sb = StringBuilder()
        sb.append("# $title\nChannel: $author\nURL: https://www.youtube.com/watch?v=$id\n\n")
        if (desc.isNotBlank()) sb.append("## Description\n").append(desc.take(4000)).append("\n\n")
        var transcript = ""
        val baseUrl = track?.get("baseUrl").str()
        if (baseUrl != null) {
            val tReq = Request.Builder().url("$baseUrl&fmt=json3").header("User-Agent", UA).build()
            val tBody = http.newCall(tReq).await().use { r ->
                if (r.isSuccessful) withContext(Dispatchers.IO) { r.body?.string().orEmpty() } else ""
            }
            if (tBody.isNotBlank()) {
                try {
                    val events = json.parseToJsonElement(tBody).jsonObject["events"].asArr().orEmpty()
                    transcript = events.mapNotNull { e ->
                        e.asObj()?.get("segs").asArr()?.joinToString("") { it.asObj()?.get("utf8").str().orEmpty() }
                    }.joinToString(" ").replace(Regex("\\s+"), " ").trim()
                } catch (e: Exception) {
                    transcript = ""
                }
            }
        }
        if (transcript.isBlank()) {
            if (desc.isBlank()) throw WebException("No transcript or description available for this video")
            sb.append("(No transcript available for this video; only title and description were read.)\n")
        } else {
            sb.append("## Transcript (${track?.get("languageCode").str() ?: "?"})\n").append(transcript)
        }
        return Page(url, title, sb.toString().take(MAX_CHARS), extractLinks(desc), "youtube")
    }
}
