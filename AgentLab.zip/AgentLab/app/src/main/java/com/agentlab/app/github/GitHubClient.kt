package com.agentlab.app.github

import com.agentlab.app.data.SettingsStore
import com.agentlab.app.llm.await
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

class GitHubException(message: String) : Exception(message)
class RunInfo(val id: Long, val status: String, val conclusion: String, val url: String, val event: String)

class GitHubClient(private val http: OkHttpClient, private val settings: SettingsStore) {
    private val jt = "application/json".toMediaType()

    fun repo(): String {
        val r = settings.current.githubRepo.trim().removePrefix("https://github.com/").removeSuffix(".git").trim('/')
        if (!r.matches(Regex("[\\w.-]+/[\\w.-]+"))) throw GitHubException("Set the GitHub repo as owner/repo in Settings.")
        return r
    }

    fun baseBranch(): String = settings.current.githubBaseBranch.ifBlank { "main" }

    private fun token(): String {
        val t = settings.current.githubToken
        if (t.isBlank()) throw GitHubException("Set your GitHub token in Settings.")
        return t
    }

    private suspend fun call(method: String, path: String, body: JSONObject? = null, accept: String = "application/vnd.github+json"): String {
        val url = if (path.startsWith("http")) path else "https://api.github.com/repos/${repo()}$path"
        val rb = if (method == "GET") null else (body ?: JSONObject()).toString().toRequestBody(jt)
        val req = Request.Builder().url(url)
            .header("Authorization", "Bearer ${token()}")
            .header("Accept", accept)
            .header("X-GitHub-Api-Version", "2022-11-28")
            .header("User-Agent", "AgentLab")
            .method(method, rb).build()
        val resp = http.newCall(req).await()
        resp.use { r ->
            val text = withContext(Dispatchers.IO) { r.body?.string().orEmpty() }
            if (!r.isSuccessful) {
                val msg = try { JSONObject(text).optString("message", text) } catch (e: Exception) { text }
                throw GitHubException("GitHub HTTP ${r.code}: ${msg.take(300)}")
            }
            return text
        }
    }

    private fun guardBranch(branch: String) {
        val b = branch.trim()
        if (b.isEmpty() || b == baseBranch() || b == "main" || b == "master") {
            throw GitHubException("Refusing to write to '$branch'. The agent never pushes to the main branch; it only works on its own branches.")
        }
    }

    suspend fun branchSha(branch: String): String =
        JSONObject(call("GET", "/git/ref/heads/$branch")).getJSONObject("object").getString("sha")

    suspend fun createBranch(name: String, fromSha: String) {
        guardBranch(name)
        call("POST", "/git/refs", JSONObject().put("ref", "refs/heads/$name").put("sha", fromSha))
    }

    suspend fun listFiles(ref: String): List<String> {
        val arr = JSONObject(call("GET", "/git/trees/$ref?recursive=1")).optJSONArray("tree") ?: JSONArray()
        return (0 until arr.length()).mapNotNull { i ->
            val o = arr.getJSONObject(i)
            if (o.optString("type") == "blob") o.getString("path") else null
        }
    }

    suspend fun readFile(path: String, ref: String): String =
        call("GET", "/contents/$path?ref=$ref", accept = "application/vnd.github.raw")

    /** One commit containing all [files] (path -> new content, or null to delete). Returns the commit sha. */
    suspend fun commitFiles(branch: String, files: Map<String, String?>, message: String): String {
        guardBranch(branch)
        val head = branchSha(branch)
        val baseTree = JSONObject(call("GET", "/git/commits/$head")).getJSONObject("tree").getString("sha")
        val entries = JSONArray()
        for ((path, content) in files) {
            val e = JSONObject().put("path", path).put("mode", "100644").put("type", "blob")
            if (content == null) e.put("sha", JSONObject.NULL) else {
                val blob = JSONObject(call("POST", "/git/blobs", JSONObject().put("content", content).put("encoding", "utf-8")))
                e.put("sha", blob.getString("sha"))
            }
            entries.put(e)
        }
        val tree = JSONObject(call("POST", "/git/trees", JSONObject().put("base_tree", baseTree).put("tree", entries))).getString("sha")
        val commit = JSONObject(
            call("POST", "/git/commits", JSONObject().put("message", message).put("tree", tree).put("parents", JSONArray().put(head)))
        ).getString("sha")
        call("PATCH", "/git/refs/heads/$branch", JSONObject().put("sha", commit).put("force", false))
        return commit
    }

    /** Returns (number, url). */
    suspend fun openPullRequest(title: String, body: String, head: String): Pair<Int, String> {
        guardBranch(head)
        val o = JSONObject(call("POST", "/pulls", JSONObject().put("title", title).put("body", body).put("head", head).put("base", baseBranch())))
        return o.getInt("number") to o.getString("html_url")
    }

    suspend fun runForSha(sha: String): RunInfo? {
        val arr = JSONObject(call("GET", "/actions/runs?head_sha=$sha&per_page=10")).optJSONArray("workflow_runs") ?: return null
        val runs = (0 until arr.length()).map { arr.getJSONObject(it) }
        val pick = runs.firstOrNull { it.optString("event") == "push" } ?: runs.firstOrNull() ?: return null
        return RunInfo(
            pick.getLong("id"), pick.optString("status"), pick.optString("conclusion"),
            pick.optString("html_url"), pick.optString("event")
        )
    }

    suspend fun runById(id: Long): RunInfo {
        val o = JSONObject(call("GET", "/actions/runs/$id"))
        return RunInfo(o.getLong("id"), o.optString("status"), o.optString("conclusion"), o.optString("html_url"), o.optString("event"))
    }

    /** Raw log text of the first failed job of a run (empty if none). */
    suspend fun failedJobLog(runId: Long): String {
        val jobs = JSONObject(call("GET", "/actions/runs/$runId/jobs")).optJSONArray("jobs") ?: return ""
        for (i in 0 until jobs.length()) {
            val j = jobs.getJSONObject(i)
            if (j.optString("conclusion") == "failure") {
                return call("GET", "/actions/jobs/${j.getLong("id")}/logs", accept = "application/vnd.github+json")
            }
        }
        return ""
    }

    /** Whether the run has an uploaded artifact (the APK). */
    suspend fun hasArtifact(runId: Long): Boolean =
        JSONObject(call("GET", "/actions/runs/$runId/artifacts")).optInt("total_count") > 0
}
