package com.agentlab.app.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "sources")
data class SourceEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: String, // URL | TOPIC | QUERY
    val value: String,
    val enabled: Boolean = true,
    val lastRead: Long = 0,
    val entryCount: Int = 0,
    val lastError: String? = null
)

@Entity(tableName = "knowledge")
data class KnowledgeEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val summary: String,
    val sourceUrl: String,
    val createdAt: Long,
    val confidence: Float,
    val contentHash: String,
    val embKind: String = "",
    val embedding: ByteArray? = null
)

/** Light projection used by the Knowledge list so embeddings are not loaded into the UI. */
data class KnowledgeRow(
    val id: Long,
    val title: String,
    val summary: String,
    val sourceUrl: String,
    val createdAt: Long,
    val confidence: Float
)

@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val role: String, // user | assistant
    val content: String,
    val citations: String = "", // lines of "id\ttitle\turl"
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "skills")
data class SkillEntity(
    @PrimaryKey val name: String,
    val description: String,
    val code: String,
    val version: Int,
    val updatedAt: Long,
    val enabled: Boolean = true,
    val lastGoodVersion: Int = 0
)

@Entity(tableName = "skill_versions")
data class SkillVersionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val skillName: String,
    val version: Int,
    val code: String,
    val note: String,
    val createdAt: Long
)

@Entity(tableName = "test_questions")
data class TestQuestionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val question: String,
    val reference: String = "",
    val generated: Boolean = false
)

@Entity(tableName = "improvements")
data class ImprovementEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val runId: Long,
    val kind: String, // PROMPT | SKILL | STRATEGY
    val target: String, // "system_prompt" | "research_strategy" | skill name
    val reason: String,
    val oldText: String,
    val newText: String,
    val status: String, // PENDING | APPLIED | AUTO_APPLIED | REJECTED | ROLLED_BACK
    val scoreBefore: Float,
    val scoreAfter: Float,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "logs")
data class LogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val runId: Long,
    val ts: Long = System.currentTimeMillis(),
    val level: String,
    val message: String
)

@Entity(tableName = "git_tasks")
data class GitTaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val description: String,
    val branch: String = "",
    val prNumber: Int = 0,
    val prUrl: String = "",
    val status: String = "NEW", // NEW | WORKING | PR_OPEN | FAILED | DONE
    val buildStatus: String = "", // queued | in_progress | success | failure | ...
    val buildUrl: String = "",
    val artifactUrl: String = "",
    val attempts: Int = 0,
    val lastError: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Dao
interface SourceDao {
    @Query("SELECT * FROM sources ORDER BY id DESC") fun observeAll(): Flow<List<SourceEntity>>
    @Query("SELECT * FROM sources") suspend fun getAll(): List<SourceEntity>
    @Query("SELECT * FROM sources WHERE enabled = 1") suspend fun getEnabled(): List<SourceEntity>
    @Query("SELECT * FROM sources WHERE id = :id") suspend fun get(id: Long): SourceEntity?
    @Insert suspend fun insert(s: SourceEntity): Long
    @Update suspend fun update(s: SourceEntity)
    @Delete suspend fun delete(s: SourceEntity)
}

@Dao
interface KnowledgeDao {
    @Query("SELECT id, title, summary, sourceUrl, createdAt, confidence FROM knowledge ORDER BY createdAt DESC")
    fun observeRows(): Flow<List<KnowledgeRow>>
    @Query("SELECT * FROM knowledge") suspend fun getAll(): List<KnowledgeEntity>
    @Query("SELECT * FROM knowledge WHERE id = :id") suspend fun get(id: Long): KnowledgeEntity?
    @Query("SELECT * FROM knowledge WHERE contentHash = :hash LIMIT 1") suspend fun findByHash(hash: String): KnowledgeEntity?
    @Query("SELECT COUNT(*) FROM knowledge") suspend fun count(): Int
    @Query("SELECT COUNT(*) FROM knowledge") fun observeCount(): Flow<Int>
    @Query("SELECT COUNT(*) FROM knowledge WHERE sourceUrl = :url") suspend fun countForUrl(url: String): Int
    @Insert suspend fun insert(e: KnowledgeEntity): Long
    @Update suspend fun update(e: KnowledgeEntity)
    @Query("DELETE FROM knowledge WHERE id = :id") suspend fun deleteById(id: Long)
}

@Dao
interface ChatDao {
    @Query("SELECT * FROM chat_messages ORDER BY id ASC") fun observeAll(): Flow<List<ChatMessageEntity>>
    @Query("SELECT * FROM (SELECT * FROM chat_messages ORDER BY id DESC LIMIT :n) ORDER BY id ASC")
    suspend fun recent(n: Int): List<ChatMessageEntity>
    @Insert suspend fun insert(m: ChatMessageEntity): Long
    @Update suspend fun update(m: ChatMessageEntity)
    @Query("DELETE FROM chat_messages") suspend fun clear()
}

@Dao
interface SkillDao {
    @Query("SELECT * FROM skills ORDER BY name") fun observeAll(): Flow<List<SkillEntity>>
    @Query("SELECT * FROM skills ORDER BY name") suspend fun getAll(): List<SkillEntity>
    @Query("SELECT * FROM skills WHERE name = :name") suspend fun get(name: String): SkillEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(s: SkillEntity)
    @Query("DELETE FROM skills WHERE name = :name") suspend fun delete(name: String)
    @Query("SELECT * FROM skill_versions WHERE skillName = :name ORDER BY version DESC")
    fun observeVersions(name: String): Flow<List<SkillVersionEntity>>
    @Query("SELECT * FROM skill_versions WHERE skillName = :name AND version = :version LIMIT 1")
    suspend fun getVersion(name: String, version: Int): SkillVersionEntity?
    @Insert suspend fun insertVersion(v: SkillVersionEntity)
    @Query("DELETE FROM skill_versions WHERE skillName = :name") suspend fun deleteVersions(name: String)
}

@Dao
interface TestQuestionDao {
    @Query("SELECT * FROM test_questions ORDER BY id") fun observeAll(): Flow<List<TestQuestionEntity>>
    @Query("SELECT * FROM test_questions ORDER BY id") suspend fun getAll(): List<TestQuestionEntity>
    @Insert suspend fun insert(q: TestQuestionEntity): Long
    @Update suspend fun update(q: TestQuestionEntity)
    @Delete suspend fun delete(q: TestQuestionEntity)
    @Query("DELETE FROM test_questions WHERE generated = 1") suspend fun deleteGenerated()
}

@Dao
interface ImprovementDao {
    @Query("SELECT * FROM improvements ORDER BY id DESC") fun observeAll(): Flow<List<ImprovementEntity>>
    @Query("SELECT * FROM improvements WHERE id = :id") suspend fun get(id: Long): ImprovementEntity?
    @Insert suspend fun insert(i: ImprovementEntity): Long
    @Update suspend fun update(i: ImprovementEntity)
}

@Dao
interface LogDao {
    @Query("SELECT * FROM (SELECT * FROM logs ORDER BY id DESC LIMIT :n) ORDER BY id ASC")
    fun observeRecent(n: Int): Flow<List<LogEntity>>
    @Insert suspend fun insert(l: LogEntity)
    @Query("DELETE FROM logs") suspend fun clear()
    @Query("SELECT COALESCE(MAX(runId), 0) FROM logs") suspend fun maxRunId(): Long
}

@Dao
interface GitTaskDao {
    @Query("SELECT * FROM git_tasks ORDER BY id DESC") fun observeAll(): Flow<List<GitTaskEntity>>
    @Query("SELECT * FROM git_tasks WHERE id = :id") suspend fun get(id: Long): GitTaskEntity?
    @Insert suspend fun insert(t: GitTaskEntity): Long
    @Update suspend fun update(t: GitTaskEntity)
}

@Database(
    entities = [
        SourceEntity::class, KnowledgeEntity::class, ChatMessageEntity::class, SkillEntity::class,
        SkillVersionEntity::class, TestQuestionEntity::class, ImprovementEntity::class,
        LogEntity::class, GitTaskEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDb : RoomDatabase() {
    abstract fun sources(): SourceDao
    abstract fun knowledge(): KnowledgeDao
    abstract fun chat(): ChatDao
    abstract fun skills(): SkillDao
    abstract fun testQuestions(): TestQuestionDao
    abstract fun improvements(): ImprovementDao
    abstract fun logs(): LogDao
    abstract fun gitTasks(): GitTaskDao

    companion object {
        fun create(context: Context): AppDb =
            Room.databaseBuilder(context.applicationContext, AppDb::class.java, "agentlab.db")
                .fallbackToDestructiveMigration()
                .build()
    }
}
