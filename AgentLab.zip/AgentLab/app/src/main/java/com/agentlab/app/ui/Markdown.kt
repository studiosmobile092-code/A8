package com.agentlab.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private sealed class Block {
    class Code(val lang: String, val body: String) : Block()
    class Heading(val level: Int, val text: String) : Block()
    class Bullet(val text: String, val marker: String) : Block()
    class Quote(val text: String) : Block()
    class Para(val text: String) : Block()
}

private fun parseBlocks(src: String): List<Block> {
    val out = ArrayList<Block>()
    val lines = src.lines()
    var i = 0
    val para = StringBuilder()
    fun flush() { if (para.isNotBlank()) out.add(Block.Para(para.toString().trim())); para.clear() }
    while (i < lines.size) {
        val line = lines[i]
        val t = line.trimStart()
        if (t.startsWith("```")) {
            flush()
            val lang = t.removePrefix("```").trim()
            val body = StringBuilder()
            i++
            while (i < lines.size && !lines[i].trimStart().startsWith("```")) { body.append(lines[i]).append('\n'); i++ }
            out.add(Block.Code(lang, body.toString().trimEnd('\n')))
            i++ // skip closing fence (or run past the end while streaming)
            continue
        }
        val h = Regex("^(#{1,6})\\s+(.*)").find(t)
        val b = Regex("^([-*+])\\s+(.*)").find(t)
        val n = Regex("^(\\d{1,3}[.)])\\s+(.*)").find(t)
        when {
            h != null -> { flush(); out.add(Block.Heading(h.groupValues[1].length, h.groupValues[2])) }
            b != null -> { flush(); out.add(Block.Bullet(b.groupValues[2], "•")) }
            n != null -> { flush(); out.add(Block.Bullet(n.groupValues[2], n.groupValues[1])) }
            t.startsWith(">") -> { flush(); out.add(Block.Quote(t.removePrefix(">").trim())) }
            t.isBlank() -> flush()
            else -> { if (para.isNotEmpty()) para.append(' '); para.append(t) }
        }
        i++
    }
    flush()
    return out
}

private val INLINE = Regex("(\\*\\*[^*]+\\*\\*|`[^`\\n]+`|\\*[^*\\s][^*\\n]*\\*|\\[[^\\]]+]\\([^)]+\\))")

@Composable
private fun inlineText(text: String): AnnotatedString {
    val codeBg = MaterialTheme.colorScheme.surfaceContainerHigh
    val link = MaterialTheme.colorScheme.tertiary
    return buildAnnotatedString {
        var last = 0
        for (m in INLINE.findAll(text)) {
            append(text.substring(last, m.range.first))
            val s = m.value
            when {
                s.startsWith("**") -> withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(s.removeSurrounding("**")) }
                s.startsWith("`") -> withStyle(SpanStyle(fontFamily = FontFamily.Monospace, background = codeBg)) { append(s.removeSurrounding("`")) }
                s.startsWith("[") -> {
                    val label = s.substringAfter('[').substringBefore("](")
                    withStyle(SpanStyle(color = link, textDecoration = TextDecoration.Underline)) { append(label) }
                }
                else -> withStyle(SpanStyle(fontStyle = FontStyle.Italic)) { append(s.removeSurrounding("*")) }
            }
            last = m.range.last + 1
        }
        append(text.substring(last))
    }
}

@Composable
fun CodeBlock(lang: String, code: String, modifier: Modifier = Modifier) {
    val clipboard = LocalClipboardManager.current
    var copied by remember { mutableStateOf(false) }
    Column(
        modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surfaceContainerHigh, RoundedCornerShape(10.dp))
    ) {
        Row(Modifier.fillMaxWidth().padding(start = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                lang.ifBlank { "code" }, style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f)
            )
            IconButton(onClick = { clipboard.setText(AnnotatedString(code)); copied = true }) {
                Icon(
                    if (copied) Icons.Filled.Check else Icons.Filled.ContentCopy,
                    contentDescription = "Copy code", tint = MaterialTheme.colorScheme.primary
                )
            }
        }
        Text(
            code,
            fontFamily = FontFamily.Monospace, fontSize = 13.sp, lineHeight = 18.sp,
            modifier = Modifier.horizontalScroll(rememberScrollState()).padding(start = 12.dp, end = 12.dp, bottom = 12.dp)
        )
    }
}

@Composable
fun Markdown(text: String, modifier: Modifier = Modifier) {
    val blocks = remember(text) { parseBlocks(text) }
    Column(modifier, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        for (b in blocks) {
            when (b) {
                is Block.Code -> CodeBlock(b.lang, b.body)
                is Block.Heading -> Text(
                    inlineText(b.text),
                    style = when (b.level) {
                        1 -> MaterialTheme.typography.titleLarge
                        2 -> MaterialTheme.typography.titleMedium
                        else -> MaterialTheme.typography.titleSmall
                    },
                    fontWeight = FontWeight.Bold
                )
                is Block.Bullet -> Row {
                    Text(b.marker, modifier = Modifier.padding(start = 6.dp, end = 8.dp))
                    Text(inlineText(b.text), style = MaterialTheme.typography.bodyMedium)
                }
                is Block.Quote -> Text(
                    inlineText(b.text), style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(start = 10.dp)
                )
                is Block.Para -> Text(inlineText(b.text), style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}
