package com.agentlab.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.unit.dp
import com.agentlab.app.container
import com.agentlab.app.data.KnowledgeRow
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun KnowledgeScreen() {
    val c = LocalContext.current.container
    val all by c.db.knowledge().observeRows().collectAsState(emptyList())
    var query by remember { mutableStateOf("") }
    var found by remember { mutableStateOf<List<KnowledgeRow>?>(null) }
    var editing by remember { mutableStateOf<KnowledgeRow?>(null) }
    var adding by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf<KnowledgeRow?>(null) }
    var expanded by remember { mutableStateOf(setOf<Long>()) }
    val scope = rememberCoroutineScope()
    val uri = LocalUriHandler.current

    LaunchedEffect(query, all.size) {
        if (query.isBlank()) { found = null; return@LaunchedEffect }
        delay(300)
        found = try {
            c.knowledge.search(query, 40).map {
                KnowledgeRow(it.entry.id, it.entry.title, it.entry.summary, it.entry.sourceUrl, it.entry.createdAt, it.entry.confidence)
            }
        } catch (e: Exception) { emptyList() }
    }
    val rows = found ?: all

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Knowledge", style = MaterialTheme.typography.titleLarge)
                Text("${all.size} entries" + if (found != null) " · ${rows.size} matches" else "", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Button(onClick = { adding = true }) { Icon(Icons.Filled.Add, null); Text("Add") }
        }
        OutlinedTextField(
            value = query, onValueChange = { query = it }, singleLine = true,
            placeholder = { Text("Search by meaning or keyword") },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
        )
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (rows.isEmpty()) item {
                Text(
                    if (query.isBlank()) "Nothing learned yet. Add sources and tap RUN in the Agent tab." else "No matches.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            items(rows, key = { it.id }) { k ->
                val open = k.id in expanded
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
                    modifier = Modifier.clickable { expanded = if (open) expanded - k.id else expanded + k.id }
                ) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(k.title, style = MaterialTheme.typography.titleSmall)
                        Text(k.summary, style = MaterialTheme.typography.bodyMedium, maxLines = if (open) Int.MAX_VALUE else 3)
                        Text(
                            k.sourceUrl, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.tertiary,
                            maxLines = 1, modifier = Modifier.clickable(enabled = k.sourceUrl.startsWith("http")) { runCatching { uri.openUri(k.sourceUrl) } }
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(fmtDate(k.createdAt), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
                            Text("Confidence ${(k.confidence * 100).toInt()}%", style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(end = 8.dp))
                            LinearProgressIndicator(progress = { k.confidence }, modifier = Modifier.weight(0.5f))
                            IconButton(onClick = { editing = k }) { Icon(Icons.Filled.Edit, contentDescription = "Edit") }
                            IconButton(onClick = { deleting = k }) { Icon(Icons.Filled.Delete, contentDescription = "Delete") }
                        }
                    }
                }
            }
        }
    }

    if (adding || editing != null) {
        val cur = editing
        EntryDialog(
            initial = cur,
            onDismiss = { adding = false; editing = null },
            onSave = { title, summary, conf ->
                scope.launch {
                    if (cur == null) c.knowledge.add(title, summary, "manual entry", conf)
                    else c.knowledge.update(cur.id, title, summary, conf)
                }
                adding = false; editing = null
            }
        )
    }
    deleting?.let { k ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("Delete entry?") },
            text = { Text(k.title) },
            confirmButton = { TextButton(onClick = { scope.launch { c.knowledge.delete(k.id) }; deleting = null }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun EntryDialog(initial: KnowledgeRow?, onDismiss: () -> Unit, onSave: (String, String, Float) -> Unit) {
    var title by remember { mutableStateOf(initial?.title ?: "") }
    var summary by remember { mutableStateOf(initial?.summary ?: "") }
    var conf by remember { mutableStateOf(initial?.confidence ?: 0.8f) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Add entry" else "Edit entry") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("Title") }, singleLine = true)
                OutlinedTextField(summary, { summary = it }, label = { Text("Summary") }, minLines = 4, maxLines = 10)
                Text("Confidence ${(conf * 100).toInt()}%")
                Slider(conf, { conf = it })
            }
        },
        confirmButton = {
            TextButton(enabled = title.isNotBlank() && summary.length >= 20, onClick = { onSave(title, summary, conf) }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
