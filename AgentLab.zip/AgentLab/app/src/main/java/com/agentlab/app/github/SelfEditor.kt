package com.agentlab.app.github

import com.agentlab.app.Container
import com.agentlab.app.agent.extractJsonArray
import com.agentlab.app.agent.extractJsonObject
import com.agentlab.app.data.GitTaskEntity
import com.agentlab.app.llm.LlmMessage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

/**
 * The GitHub loop: branch -> edit -> single commit -> pull request -> watch the Actions build ->
 * on failure read the build log and push a fix (max [MAX_FIXES] fix pushes per task). Never writes to the base branch.
 */
class SelfEditor(private val c: Container) {
    companion object {
        const val MAX_FIXES = 3
        private val ALLOWED_EXT = setOf("kt", "kts", "xml", "toml", "md", "pro", "properties", "json", "txt", "gradle")
        const val EDIT_SYSTEM =
            "You modify an Android project (Kotlin 2.0, Jetpack Compose Material 3, minSdk 26, Gradle Kotlin DSL with a version catalog). " +
                "Return ONLY JSON, no markdown fences: {\"summary\":\"what you changed and why\",\"files\":[{\"path\":\"relative/path\",\"content\":\"COMPLETE new file content\"}]}. " +
                "Give the COMPLETE content of every file you create or change. Change as little as possible, keep the project compiling, " +
                "and never touch .github/ or gradle/wrapper."
    }

    private val gh get() = c.github
    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy
    private var job: Job? = null

    suspend fun createTask(title: String, description: String): Long =
        c.db.gitTasks().insert(GitTaskEntity(title = title.trim(), description = description.trim()))

    fun start(taskId: Long) {
        if (_busy.value) return
        _busy.value = true
        job = c.scope.launch {
            try { execute(taskId) } finally { _busy.value = false }
        }
    }

    fun cancel() { job?.cancel() }

    private suspend fun save(t: GitTaskEntity): GitTaskEntity { c.db.gitTasks().update(t); return t }

    private fun allowed(path: String): Boolean {
        if (path.contains("..") || path.startsWith("/") || path.startsWith(".github/") || path.startsWith("gradle/wrapper")) return false
        val ext = path.substringAfterLast('.', "")
        return ext in ALLOWED_EXT && path.length < 200
    }

    private fun slug(s: String) = s.lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-').take(30).ifBlank { "change" }

    private suspend fun execute(taskId: Long) {
        var t = c.db.gitTasks().get(taskId) ?: return
        try {
            t = save(t.copy(status = "WORKING", lastError = "", attempts = 0, buildStatus = ""))
            val base = gh.baseBranch()
            val branch = t.branch.ifBlank { "agentlab/${slug(t.title)}-${System.currentTimeMillis() / 1000}" }
            if (t.branch.isBlank()) {
                gh.createBranch(branch, gh.branchSha(base))
                t = save(t.copy(branch = branch))
            }
            val all = gh.listFiles(branch).filter { allowed(it) }
            val touched = LinkedHashSet<String>()

            // 1. pick files to read
            val pickOut = c.llm.complete(
                listOf(LlmMessage("user", "TASK: ${t.title}\n${t.description}\n\nPROJECT FILES:\n" + all.take(400).joinToString("\n"))),
                system = "Choose the files (at most 6) that must be read or changed to do the task. Return ONLY a JSON array of paths copied from the list.",
                temperature = 0.1f, maxTokens = 500
            )
            val picked = JSONArray(extractJsonArray(pickOut) ?: "[]").let { a -> (0 until a.length()).map { a.optString(it) } }
                .filter { it in all }.take(6)
            val current = picked.associateWith { gh.readFile(it, branch).take(30_000) }

            // 2. first implementation
            var edit = generateEdits(t, current, all, null)
            var sha = gh.commitFiles(branch, edit.files, "AgentLab: ${t.title}\n\n${edit.summary}".take(2000))
            touched.addAll(edit.files.keys)
            val (num, url) = gh.openPullRequest(
                t.title,
                "## Summary\n${edit.summary}\n\n## Task\n${t.description}\n\n---\nOpened by Agent Lab. It is never merged automatically: review and merge it yourself.",
                branch
            )
            t = save(t.copy(prNumber = num, prUrl = url, status = "PR_OPEN"))

            // 3. watch the build, fix failures
            while (true) {
                val run = waitForRun(sha, t).also { t = c.db.gitTasks().get(taskId) ?: t }
                if (run.conclusion == "success") {
                    t = save(t.copy(status = "DONE", buildStatus = "success", buildUrl = run.url, artifactUrl = run.url, lastError = ""))
                    return
                }
                if (t.attempts >= MAX_FIXES) {
                    t = save(t.copy(status = "FAILED", buildStatus = run.conclusion, buildUrl = run.url, lastError = "Build still failing after $MAX_FIXES fix attempts. See the build log."))
                    return
                }
                val errors = condense(gh.failedJobLog(run.id))
                t = save(t.copy(buildStatus = "fixing", buildUrl = run.url, attempts = t.attempts + 1))
                val names = LinkedHashSet<String>(touched)
                Regex("[\\w./-]+\\.(kt|kts|xml|toml)").findAll(errors).map { it.value.trimStart('/') }
                    .mapNotNull { p -> all.firstOrNull { it == p || it.endsWith("/$p") || p.endsWith(it) } }
                    .take(4).forEach { names.add(it) }
                val files = names.filter { allowed(it) }.take(8).associateWith { runCatching { gh.readFile(it, branch).take(30_000) }.getOrDefault("") }
                edit = generateEdits(t, files, all, errors)
                sha = gh.commitFiles(branch, edit.files, "AgentLab: fix build (attempt ${t.attempts})\n\n${edit.summary}".take(2000))
                touched.addAll(edit.files.keys)
                t = save(t.copy(status = "PR_OPEN", buildStatus = "queued"))
            }
        } catch (e: CancellationException) {
            c.db.gitTasks().get(taskId)?.let { c.db.gitTasks().update(it.copy(status = "FAILED", lastError = "Cancelled")) }
            throw e
        } catch (e: Exception) {
            c.db.gitTasks().get(taskId)?.let { c.db.gitTasks().update(it.copy(status = "FAILED", lastError = e.message ?: e.javaClass.simpleName)) }
        }
    }

    private class Edit(val summary: String, val files: Map<String, String?>)

    private suspend fun generateEdits(t: GitTaskEntity, files: Map<String, String>, all: List<String>, errors: String?): Edit {
        val prompt = buildString {
            append("TASK: ${t.title}\n${t.description}\n\nPROJECT FILES:\n${all.take(300).joinToString("\n")}\n\nCURRENT FILE CONTENTS:\n")
            files.forEach { (p, body) -> append("=== $p ===\n$body\n") }
            if (errors != null) append("\nTHE GITHUB ACTIONS BUILD FAILED. Fix these errors:\n$errors\n")
        }
        val out = c.llm.complete(listOf(LlmMessage("user", prompt)), EDIT_SYSTEM, temperature = 0.2f, maxTokens = 12_000)
        val o = try { JSONObject(extractJsonObject(out) ?: throw IllegalStateException("no JSON")) } catch (e: Exception) {
            throw GitHubException("The model did not return valid JSON for the edit. Try again or raise Max tokens in Settings.")
        }
        val arr = o.optJSONArray("files") ?: throw GitHubException("The model returned no files.")
        val map = LinkedHashMap<String, String?>()
        for (i in 0 until minOf(arr.length(), 8)) {
            val f = arr.getJSONObject(i)
            val p = f.optString("path").trim()
            if (!allowed(p)) throw GitHubException("The model tried to change a protected or unsupported path: $p")
            map[p] = f.optString("content")
        }
        if (map.isEmpty()) throw GitHubException("The model proposed no changes.")
        return Edit(o.optString("summary", "Changes by Agent Lab"), map)
    }

    private suspend fun waitForRun(sha: String, task: GitTaskEntity): RunInfo {
        val deadline = System.currentTimeMillis() + 25 * 60_000L
        var id = 0L
        while (System.currentTimeMillis() < deadline) {
            val r = if (id == 0L) gh.runForSha(sha) else gh.runById(id)
            if (r != null) {
                id = r.id
                c.db.gitTasks().get(task.id)?.let {
                    c.db.gitTasks().update(it.copy(buildStatus = if (r.status == "completed") r.conclusion else r.status, buildUrl = r.url))
                }
                if (r.status == "completed") return r
            }
            delay(15_000)
        }
        throw GitHubException("Timed out waiting for the GitHub Actions build.")
    }

    private fun condense(log: String): String {
        if (log.isBlank()) return "(no log available)"
        val lines = log.lines().map { it.replace(Regex("^\\d{4}-\\d\\d-\\d\\dT[\\d:.]+Z\\s?"), "") }
        val re = Regex("(^e: |error:|FAILED|What went wrong|Execution failed|Unresolved reference|\\.kt:\\d+)")
        val hits = lines.filter { re.containsMatchIn(it) }.distinct()
        val text = if (hits.isNotEmpty()) hits.joinToString("\n") else lines.takeLast(60).joinToString("\n")
        return text.takeLast(6000)
    }

    /** Re-reads the latest build for a task's branch (useful after restarting the app). */
    suspend fun refresh(taskId: Long) {
        val t = c.db.gitTasks().get(taskId) ?: return
        if (t.branch.isBlank()) return
        try {
            val r = gh.runForSha(gh.branchSha(t.branch)) ?: return
            val ok = r.status == "completed" && r.conclusion == "success"
            c.db.gitTasks().update(
                t.copy(
                    buildStatus = if (r.status == "completed") r.conclusion else r.status, buildUrl = r.url,
                    artifactUrl = if (ok) r.url else t.artifactUrl,
                    status = if (ok) "DONE" else t.status
                )
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            c.db.gitTasks().update(t.copy(lastError = e.message ?: "refresh failed"))
        }
    }
}
