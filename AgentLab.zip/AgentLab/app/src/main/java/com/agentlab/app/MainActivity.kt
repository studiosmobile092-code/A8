package com.agentlab.app

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.agentlab.app.ui.AgentLabTheme
import com.agentlab.app.ui.AgentScreen
import com.agentlab.app.ui.ChatScreen
import com.agentlab.app.ui.KnowledgeScreen
import com.agentlab.app.ui.SettingsScreen
import com.agentlab.app.ui.SkillsScreen
import com.agentlab.app.ui.SourcesScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AgentLabTheme {
                val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
                LaunchedEffect(Unit) {
                    if (Build.VERSION.SDK_INT >= 33) perm.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
                AppRoot()
            }
        }
    }
}

private class Tab(val title: String, val icon: ImageVector)

private val TABS = listOf(
    Tab("Chat", Icons.Filled.Chat),
    Tab("Sources", Icons.Filled.Link),
    Tab("Knowledge", Icons.Filled.MenuBook),
    Tab("Skills", Icons.Filled.Code),
    Tab("Settings", Icons.Filled.Settings),
    Tab("Agent", Icons.Filled.PlayArrow)
)

@Composable
fun AppRoot() {
    val ctx = LocalContext.current
    var tab by rememberSaveable { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { ctx.container.init() }
    Scaffold(
        bottomBar = {
            NavigationBar {
                TABS.forEachIndexed { i, t ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Icon(t.icon, contentDescription = t.title) },
                        label = { Text(t.title) }
                    )
                }
            }
        }
    ) { pad ->
        Surface(Modifier.fillMaxSize().padding(pad)) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
                Box(Modifier.widthIn(max = 1100.dp).fillMaxWidth()) {
                    when (tab) {
                        0 -> ChatScreen()
                        1 -> SourcesScreen()
                        2 -> KnowledgeScreen()
                        3 -> SkillsScreen()
                        4 -> SettingsScreen()
                        else -> AgentScreen()
                    }
                }
            }
        }
    }
}
