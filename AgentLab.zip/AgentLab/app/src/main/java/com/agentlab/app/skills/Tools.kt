package com.agentlab.app.skills

import com.agentlab.app.knowledge.KnowledgeBase
import com.agentlab.app.llm.LlmClient
import com.agentlab.app.llm.LlmMessage
import com.agentlab.app.web.WebReader
import com.agentlab.app.web.WebSearch
import org.json.JSONArray
import org.json.JSONObject

/**
 * The complete list of capabilities a skill can reach:
 * fetch_url, web_search, read_knowledge, save_knowledge, call_llm, run_skill. Nothing else.
 */
class Tools(
    private val web: WebReader,
    private val search: WebSearch,
    private val kb: KnowledgeBase,
    private val llm: LlmClient
) : ToolHost {
    lateinit var skills: SkillManager
    /** Called for every tool call so the Agent screen can log it. */
    var onCall: ((String) -> Unit)? = null
    /** While true (sandbox testing of candidate changes), save_knowledge reports success without writing anything. */
    @Volatile var dryRun: Boolean = false

    override suspend fun call(tool: String, argsJson: String, depth: Int): String {
        return try {
            val a = if (argsJson.isBlank()) JSONObject() else JSONObject(argsJson)
            onCall?.invoke("tool $tool")
            val v: Any? = when (tool) {
                "fetch_url" -> {
                    val p = web.read(a.getString("url"))
                    JSONObject().put("url", p.url).put("title", p.title).put("text", p.text.take(20_000))
                        .put("links", JSONArray(p.links.take(50)))
                }
                "web_search" -> {
                    val r = search.search(a.getString("query"), a.optInt("limit", 5).coerceIn(1, 10))
                    JSONArray().also { arr ->
                        r.forEach { arr.put(JSONObject().put("title", it.title).put("url", it.url).put("snippet", it.snippet)) }
                    }
                }
                "read_knowledge" -> {
                    val hits = kb.search(a.getString("query"), a.optInt("limit", 5).coerceIn(1, 10))
                    JSONArray().also { arr ->
                        hits.forEach {
                            arr.put(
                                JSONObject().put("id", it.entry.id).put("title", it.entry.title)
                                    .put("summary", it.entry.summary).put("url", it.entry.sourceUrl)
                                    .put("confidence", it.entry.confidence.toDouble())
                            )
                        }
                    }
                }
                "save_knowledge" -> if (dryRun) JSONObject().put("id", -1).put("dryRun", true) else {
                    val id = kb.add(
                        a.getString("title"), a.getString("summary"), a.optString("url", "skill"),
                        a.optDouble("confidence", 0.5).toFloat()
                    )
                    if (id == null) JSONObject().put("duplicate", true) else JSONObject().put("id", id)
                }
                "call_llm" -> {
                    val sys = a.optString("system", "").ifBlank { null }
                    llm.complete(
                        listOf(LlmMessage("user", a.getString("prompt"))), sys,
                        if (a.has("temperature")) a.getDouble("temperature").toFloat() else null,
                        if (a.has("maxTokens")) a.getInt("maxTokens") else null
                    )
                }
                "run_skill" -> {
                    val input = a.opt("input")?.let { if (it == JSONObject.NULL) "{}" else it.toString() } ?: "{}"
                    val (res, _) = skills.run(a.getString("name"), input, depth + 1)
                    if (!res.ok) throw IllegalStateException(res.value)
                    parseJson(res.value)
                }
                else -> throw IllegalArgumentException("Unknown tool '$tool'")
            }
            JSONObject().put("value", v ?: JSONObject.NULL).toString()
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            JSONObject().put("error", e.message ?: e.javaClass.simpleName).toString()
        }
    }

    private fun parseJson(s: String): Any = try {
        JSONObject("{\"v\":$s}").get("v")
    } catch (e: Exception) {
        s
    }
}
