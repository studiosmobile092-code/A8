package com.agentlab.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import com.agentlab.app.container
import com.agentlab.app.data.ChatMessageEntity
import kotlinx.coroutines.launch

@Composable
fun ChatScreen() {
    val c = LocalContext.current.container
    val ctl = c.chatController
    val messages by c.db.chat().observeAll().collectAsState(emptyList())
    val kbCount by c.db.knowledge().observeCount().collectAsState(0)
    val streaming by ctl.streaming.collectAsState()
    val error by ctl.error.collectAsState()
    var input by remember { mutableStateOf("") }
    val list = rememberLazyListState()
    val scope = rememberCoroutineScope()

    LaunchedEffect(messages.size, streaming?.length) {
        val n = messages.size + if (streaming != null) 1 else 0
        if (n > 0) list.scrollToItem(n - 1)
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 4.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Chat", style = MaterialTheme.typography.titleLarge)
                Text("$kbCount knowledge entries available", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            IconButton(onClick = { scope.launch { ctl.clear() } }) { Icon(Icons.Filled.DeleteSweep, contentDescription = "Clear history") }
        }
        LazyColumn(
            Modifier.weight(1f).fillMaxWidth(), state = list,
            contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (messages.isEmpty() && streaming == null) {
                item {
                    Text(
                        "Ask anything. Answers use the Knowledge base and cite the entries they relied on. " +
                            "Add sources and tap RUN in the Agent tab to teach it more.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            items(messages, key = { it.id }) { m -> Bubble(m) }
            streaming?.let { s ->
                item {
                    if (s.isEmpty()) Text("Thinking…", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    else Bubble(ChatMessageEntity(role = "assistant", content = s))
                }
            }
            error?.let { e ->
                item { Text("Error: $e", color = MaterialTheme.colorScheme.error) }
            }
        }
        Row(
            Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = input, onValueChange = { input = it },
                modifier = Modifier.weight(1f), maxLines = 5,
                placeholder = { Text("Message") },
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences)
            )
            if (streaming != null) {
                FilledIconButton(onClick = { ctl.stop() }) { Icon(Icons.Filled.Stop, contentDescription = "Stop") }
            } else {
                FilledIconButton(
                    onClick = { ctl.send(input); input = "" },
                    enabled = input.isNotBlank()
                ) { Icon(Icons.Filled.Send, contentDescription = "Send") }
            }
        }
    }
}

@Composable
private fun Bubble(m: ChatMessageEntity) {
    val user = m.role == "user"
    val uri = LocalUriHandler.current
    Box(Modifier.fillMaxWidth(), contentAlignment = if (user) Alignment.CenterEnd else Alignment.CenterStart) {
        Column(
            Modifier
                .widthIn(max = 760.dp)
                .background(
                    if (user) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceContainer,
                    RoundedCornerShape(16.dp)
                )
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (user) Text(m.content, style = MaterialTheme.typography.bodyMedium) else Markdown(m.content)
            if (!user && m.citations.isNotBlank()) {
                Text("Sources used", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                m.citations.lines().filter { it.isNotBlank() }.forEach { line ->
                    val p = line.split('\t')
                    val url = p.getOrNull(2).orEmpty()
                    Text(
                        "[${p.getOrNull(0)}] ${p.getOrNull(1)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.tertiary,
                        modifier = Modifier.clickable(enabled = url.startsWith("http")) { runCatching { uri.openUri(url) } }
                    )
                }
            }
        }
    }
}
