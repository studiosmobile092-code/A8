package com.agentlab.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.agentlab.app.agent.AgentLogger
import com.agentlab.app.agent.Researcher
import com.agentlab.app.container
import com.agentlab.app.data.SourceEntity
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Date

fun fmtDate(ms: Long): String =
    if (ms <= 0) "never" else DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(ms))

@Composable
fun SourcesScreen() {
    val c = LocalContext.current.container
    val sources by c.db.sources().observeAll().collectAsState(emptyList())
    var editing by remember { mutableStateOf<SourceEntity?>(null) }
    var adding by remember { mutableStateOf(false) }
    var reading by remember { mutableStateOf(setOf<Long>()) }
    val scope = rememberCoroutineScope()

    fun readNow(s: SourceEntity) {
        reading = reading + s.id
        c.scope.launch {
            try {
                c.init()
                Researcher(c, AgentLogger(c.db, 0)).run(onlyId = s.id)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                c.db.sources().get(s.id)?.let { c.db.sources().update(it.copy(lastRead = System.currentTimeMillis(), lastError = e.message ?: "failed")) }
            } finally {
                reading = reading - s.id
            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Sources", style = MaterialTheme.typography.titleLarge)
                Text(
                    "URLs, topics and search queries the agent learns from",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Button(onClick = { adding = true }) { Icon(Icons.Filled.Add, null); Text("Add") }
        }
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (sources.isEmpty()) item {
                Text("No sources yet. Paste a link (web page, GitHub repo, PDF, YouTube video), or add a topic or search query.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            items(sources, key = { it.id }) { s ->
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer)) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(s.type, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(end = 8.dp))
                            Text(s.value, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                            Switch(checked = s.enabled, onCheckedChange = { v -> scope.launch { c.db.sources().update(s.copy(enabled = v)) } })
                        }
                        Text(
                            "Last read: ${fmtDate(s.lastRead)}  ·  ${s.entryCount} entries",
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        s.lastError?.let { Text("Error: $it", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error) }
                        Row {
                            if (s.id in reading) {
                                CircularProgressIndicator(Modifier.padding(12.dp).size(24.dp), strokeWidth = 2.dp)
                            } else IconButton(onClick = { readNow(s) }) { Icon(Icons.Filled.Refresh, contentDescription = "Read now") }
                            IconButton(onClick = { editing = s }) { Icon(Icons.Filled.Edit, contentDescription = "Edit") }
                            IconButton(onClick = { scope.launch { c.db.sources().delete(s) } }) { Icon(Icons.Filled.Delete, contentDescription = "Delete") }
                        }
                    }
                }
            }
        }
    }

    if (adding || editing != null) {
        val cur = editing
        SourceDialog(
            initial = cur,
            onDismiss = { adding = false; editing = null },
            onSave = { type, value ->
                scope.launch {
                    if (cur == null) c.db.sources().insert(SourceEntity(type = type, value = value))
                    else c.db.sources().update(cur.copy(type = type, value = value))
                }
                adding = false; editing = null
            },
            normalizeUrl = { c.web.normalizeUrl(it) }
        )
    }
}

@Composable
private fun SourceDialog(
    initial: SourceEntity?,
    onDismiss: () -> Unit,
    onSave: (String, String) -> Unit,
    normalizeUrl: (String) -> String
) {
    var type by remember { mutableStateOf(initial?.type ?: "URL") }
    var value by remember { mutableStateOf(initial?.value ?: "") }
    var err by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Add source" else "Edit source") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("URL", "TOPIC", "QUERY").forEach { t ->
                        FilterChip(selected = type == t, onClick = { type = t }, label = { Text(t) })
                    }
                }
                OutlinedTextField(
                    value = value, onValueChange = { value = it; err = null },
                    label = { Text(when (type) { "URL" -> "https://…"; "TOPIC" -> "Topic to research"; else -> "Search query" }) },
                    isError = err != null, supportingText = { err?.let { Text(it) } }
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val v = value.trim()
                if (v.isEmpty()) { err = "Required"; return@TextButton }
                if (type == "URL") {
                    try { onSave(type, normalizeUrl(v)) } catch (e: Exception) { err = e.message }
                } else onSave(type, v)
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
