package com.agentlab.app.agent

import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.agentlab.app.Container
import com.agentlab.app.llm.BudgetExceededException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Runs the autonomous loop: RESEARCH -> LEARN -> EVALUATE -> IMPROVE -> TEST -> (approval). */
class AgentController(private val c: Container) {
    private val _running = MutableStateFlow(false)
    val running: StateFlow<Boolean> = _running
    private val _status = MutableStateFlow("Idle")
    val status: StateFlow<String> = _status
    private var job: Job? = null

    @Synchronized
    fun start(context: Context) {
        if (_running.value) return
        _running.value = true
        ContextCompat.startForegroundService(context, Intent(context, AgentService::class.java))
        job = c.scope.launch { loop() }
    }

    fun stop() {
        job?.cancel()
    }

    private suspend fun loop() {
        val runId = c.db.logs().maxRunId() + 1
        val log = AgentLogger(c.db, runId)
        try {
            c.init()
            val s = c.settings.current
            if (s.apiKey.isBlank() && s.provider != "OPENAI") {
                log.error("No API key. Open Settings and enter your key first.")
                return
            }
            log.phase("RUN #$runId started")

            _status.value = "Researching"
            log.phase("1-2. RESEARCH + LEARN")
            val researcher = Researcher(c, log)
            val added = researcher.run()
            log.info("Learned $added new entries. Knowledge base now holds ${c.knowledge.count()}.")

            _status.value = "Evaluating"
            log.phase("3. EVALUATE")
            val evaluator = Evaluator(c, log)
            if (c.knowledge.count() > 0) evaluator.generateQuestions((s.evalQuestionCap / 2).coerceAtLeast(1))
            val questions = evaluator.questionSet(s.evalQuestionCap)
            if (questions.isEmpty()) {
                log.warn("No test questions. Add some in the Agent tab or let the agent learn something first.")
                return
            }
            val baseline = evaluator.evaluatePrompt(questions, c.settings.current.systemPrompt)
            log.info("Baseline score: ${pct(baseline.score)} on ${questions.size} questions")
            baseline.details.forEach { log.info("  ${pct(it.score)}  ${it.question.take(80)}") }

            _status.value = "Improving"
            Improver(c, log, researcher, evaluator, ChangeApplier(c)).run(runId, baseline, questions)

            log.phase("RUN #$runId finished")
        } catch (e: CancellationException) {
            withContext(NonCancellable) { log.warn("Stopped by user.") }
            throw e
        } catch (e: BudgetExceededException) {
            log.error(e.message ?: "Budget exceeded")
        } catch (e: Exception) {
            log.error("Run failed: ${e.message ?: e.javaClass.simpleName}")
        } finally {
            _status.value = "Idle"
            _running.value = false
        }
    }
}
