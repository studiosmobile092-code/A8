package com.agentlab.app.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.time.LocalDate

object Defaults {
    const val SYSTEM_PROMPT =
        "You are Agent Lab, a careful research assistant that learns from the web.\n" +
            "Answer using the KNOWLEDGE BASE excerpts provided with each question. " +
            "Cite the excerpts you rely on with their bracket numbers like [1] or [2]. " +
            "If the excerpts do not contain the answer, say so plainly, then answer from general knowledge and mark that part as not from the knowledge base. " +
            "Be accurate, concise and well structured. Use Markdown, and put code in fenced code blocks with a language tag."

    const val RESEARCH_STRATEGY =
        "When researching a topic: prefer primary sources (official docs, repositories, papers) over blog summaries. " +
            "Follow links that point to documentation, specifications, tutorials or source code. " +
            "Skip login pages, ads, cookie notices, navigation and unrelated pages. " +
            "Extract concrete facts, definitions, API names, numbers, steps and examples rather than vague overviews."
}

data class AppSettings(
    val provider: String = "GEMINI", // GEMINI | OPENAI | ANTHROPIC
    val model: String = "gemini-2.5-flash",
    val baseUrl: String = "https://api.openai.com/v1",
    val apiKey: String = "",
    val temperature: Float = 0.7f,
    val maxTokens: Int = 2048,
    val systemPrompt: String = Defaults.SYSTEM_PROMPT,
    val researchStrategy: String = Defaults.RESEARCH_STRATEGY,
    val embeddingModel: String = "gemini-embedding-001",
    val searchProvider: String = "DUCKDUCKGO", // DUCKDUCKGO | TAVILY | BRAVE
    val searchApiKey: String = "",
    val githubToken: String = "",
    val githubRepo: String = "", // owner/repo
    val githubBaseBranch: String = "main",
    val maxPagesPerRun: Int = 30,
    val maxLinkDepth: Int = 1,
    val dailyTokenBudget: Int = 500_000,
    val evalQuestionCap: Int = 10,
    val autoApprove: Boolean = false
)

class SettingsStore(private val context: Context) {
    private val plain: SharedPreferences = context.getSharedPreferences("agentlab_settings", Context.MODE_PRIVATE)
    private val secure: SharedPreferences = createSecure()

    private val _flow = MutableStateFlow(load())
    val flow: StateFlow<AppSettings> = _flow
    val current: AppSettings get() = _flow.value

    private val _tokens = MutableStateFlow(readTokensToday())
    val tokensToday: StateFlow<Int> = _tokens

    private fun createSecure(): SharedPreferences {
        fun build(): SharedPreferences {
            val key = MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
            return EncryptedSharedPreferences.create(
                context, "agentlab_secure", key,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        }
        return try {
            build()
        } catch (e: Exception) {
            // Keystore entry was invalidated (e.g. backup restore). Start with an empty encrypted store.
            context.deleteSharedPreferences("agentlab_secure")
            build()
        }
    }

    private fun load(): AppSettings {
        val d = AppSettings()
        return AppSettings(
            provider = plain.getString("provider", d.provider) ?: d.provider,
            model = plain.getString("model", d.model) ?: d.model,
            baseUrl = plain.getString("baseUrl", d.baseUrl) ?: d.baseUrl,
            apiKey = secure.getString("apiKey", "") ?: "",
            temperature = plain.getFloat("temperature", d.temperature),
            maxTokens = plain.getInt("maxTokens", d.maxTokens),
            systemPrompt = plain.getString("systemPrompt", d.systemPrompt) ?: d.systemPrompt,
            researchStrategy = plain.getString("researchStrategy", d.researchStrategy) ?: d.researchStrategy,
            embeddingModel = plain.getString("embeddingModel", d.embeddingModel) ?: d.embeddingModel,
            searchProvider = plain.getString("searchProvider", d.searchProvider) ?: d.searchProvider,
            searchApiKey = secure.getString("searchApiKey", "") ?: "",
            githubToken = secure.getString("githubToken", "") ?: "",
            githubRepo = plain.getString("githubRepo", "") ?: "",
            githubBaseBranch = plain.getString("githubBaseBranch", d.githubBaseBranch) ?: d.githubBaseBranch,
            maxPagesPerRun = plain.getInt("maxPagesPerRun", d.maxPagesPerRun),
            maxLinkDepth = plain.getInt("maxLinkDepth", d.maxLinkDepth),
            dailyTokenBudget = plain.getInt("dailyTokenBudget", d.dailyTokenBudget),
            evalQuestionCap = plain.getInt("evalQuestionCap", d.evalQuestionCap),
            autoApprove = plain.getBoolean("autoApprove", d.autoApprove)
        )
    }

    private fun save(s: AppSettings) {
        plain.edit()
            .putString("provider", s.provider)
            .putString("model", s.model)
            .putString("baseUrl", s.baseUrl)
            .putFloat("temperature", s.temperature)
            .putInt("maxTokens", s.maxTokens)
            .putString("systemPrompt", s.systemPrompt)
            .putString("researchStrategy", s.researchStrategy)
            .putString("embeddingModel", s.embeddingModel)
            .putString("searchProvider", s.searchProvider)
            .putString("githubRepo", s.githubRepo)
            .putString("githubBaseBranch", s.githubBaseBranch)
            .putInt("maxPagesPerRun", s.maxPagesPerRun)
            .putInt("maxLinkDepth", s.maxLinkDepth)
            .putInt("dailyTokenBudget", s.dailyTokenBudget)
            .putInt("evalQuestionCap", s.evalQuestionCap)
            .putBoolean("autoApprove", s.autoApprove)
            .apply()
        secure.edit()
            .putString("apiKey", s.apiKey)
            .putString("searchApiKey", s.searchApiKey)
            .putString("githubToken", s.githubToken)
            .apply()
    }

    @Synchronized
    fun update(block: (AppSettings) -> AppSettings) {
        val n = block(_flow.value)
        save(n)
        _flow.value = n
    }

    private fun readTokensToday(): Int {
        val today = LocalDate.now().toString()
        return if (plain.getString("tokenDay", "") == today) plain.getInt("tokensUsed", 0) else 0
    }

    @Synchronized
    fun addTokens(n: Int) {
        val today = LocalDate.now().toString()
        val base = if (plain.getString("tokenDay", "") == today) plain.getInt("tokensUsed", 0) else 0
        val total = base + n
        plain.edit().putString("tokenDay", today).putInt("tokensUsed", total).apply()
        _tokens.value = total
    }

    fun budgetRemaining(): Int = (current.dailyTokenBudget - readTokensToday()).coerceAtLeast(0)

    fun refreshTokens() { _tokens.value = readTokensToday() }
}
