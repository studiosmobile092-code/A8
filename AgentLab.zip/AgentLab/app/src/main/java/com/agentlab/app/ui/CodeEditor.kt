package com.agentlab.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Monospace code editor with a line-number gutter. Lines do not wrap, so numbers always line up. */
@Composable
fun CodeEditor(value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier, readOnly: Boolean = false) {
    val lineCount = value.count { it == '\n' } + 1
    val v = rememberScrollState()
    val h = rememberScrollState()
    val style = TextStyle(
        fontFamily = FontFamily.Monospace, fontSize = 13.sp, lineHeight = 19.sp,
        color = MaterialTheme.colorScheme.onSurface
    )
    Row(modifier.background(MaterialTheme.colorScheme.surfaceContainer).verticalScroll(v)) {
        Text(
            (1..lineCount).joinToString("\n"),
            style = style.copy(color = MaterialTheme.colorScheme.outline, textAlign = TextAlign.End),
            modifier = Modifier.background(MaterialTheme.colorScheme.surfaceContainerHigh).padding(horizontal = 8.dp, vertical = 8.dp)
        )
        Box(Modifier.weight(1f).horizontalScroll(h)) {
            BasicTextField(
                value = value, onValueChange = onChange, readOnly = readOnly,
                textStyle = style,
                cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.None, autoCorrectEnabled = false),
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp).widthIn(min = 320.dp)
            )
        }
    }
}
