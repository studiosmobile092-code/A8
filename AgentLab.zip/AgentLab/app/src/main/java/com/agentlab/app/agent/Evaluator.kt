package com.agentlab.app.agent

import com.agentlab.app.Container
import com.agentlab.app.data.TestQuestionEntity
import com.agentlab.app.llm.LlmMessage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import org.json.JSONArray
import org.json.JSONObject

class QA(val question: String, val answer: String, val score: Float, val note: String)
class EvalResult(val score: Float, val details: List<QA>)

/** EVALUATE phase: answers the test set and grades itself, using the knowledge base as the reference. */
class Evaluator(private val c: Container, private val log: AgentLogger) {

    companion object {
        const val JUDGE_SYSTEM =
            "You grade an answer for factual accuracy against a REFERENCE. Score 0-10: 10 = fully correct and complete according to the reference, " +
                "5 = partly correct or missing key details, 0 = wrong, contradicts the reference, or does not answer. " +
                "Return ONLY JSON: {\"score\": <0-10>, \"note\": \"<one short sentence>\"}"
        const val SKILL_JUDGE_SYSTEM =
            "You grade the OUTPUT of a software skill. Score 0-10 on whether the output correctly, completely and usefully fulfils the skill's stated purpose for the given INPUT. " +
                "0 = error, empty or wrong. Return ONLY JSON: {\"score\": <0-10>, \"note\": \"<one short sentence>\"}"
    }

    /** Replaces generated questions with fresh ones written from random knowledge entries. */
    suspend fun generateQuestions(count: Int) {
        c.db.testQuestions().deleteGenerated()
        val entries = c.db.knowledge().getAll().filter { it.confidence >= 0.5f }.shuffled().take(count)
        for (e in entries) {
            currentCoroutineContext().ensureActive()
            try {
                val out = c.llm.complete(
                    listOf(LlmMessage("user", "FACT:\n${e.title}\n${e.summary}")),
                    system = "Write one specific question that is answered by this fact, plus the correct answer taken only from the fact. " +
                        "Return ONLY JSON: {\"question\":\"...\",\"reference\":\"...\"}",
                    temperature = 0.3f, maxTokens = 300
                )
                val o = JSONObject(extractJsonObject(out) ?: continue)
                val q = o.optString("question")
                if (q.length > 8) c.db.testQuestions().insert(TestQuestionEntity(question = q, reference = o.optString("reference"), generated = true))
            } catch (ex: CancellationException) {
                throw ex
            } catch (ex: Exception) {
                log.warn("Question generation failed: ${ex.message}")
            }
        }
    }

    suspend fun questionSet(cap: Int): List<TestQuestionEntity> {
        val all = c.db.testQuestions().getAll()
        val user = all.filter { !it.generated }
        val gen = all.filter { it.generated }
        return (user + gen).take(cap)
    }

    private suspend fun grade(system: String, prompt: String): Pair<Float, String> {
        val out = c.llm.complete(listOf(LlmMessage("user", prompt)), system = system, temperature = 0f, maxTokens = 200)
        return try {
            val o = JSONObject(extractJsonObject(out) ?: return 0f to "unparseable grade")
            (o.optDouble("score", 0.0).toFloat() / 10f).coerceIn(0f, 1f) to o.optString("note")
        } catch (e: Exception) {
            0f to "unparseable grade"
        }
    }

    private suspend fun referenceFor(q: TestQuestionEntity): String {
        if (q.reference.isNotBlank()) return q.reference
        return c.knowledge.search(q.question, 3).joinToString("\n") { "- ${it.entry.title}: ${it.entry.summary}" }
    }

    /** Scores a system prompt: each question is answered with RAG under that prompt, then graded. */
    suspend fun evaluatePrompt(questions: List<TestQuestionEntity>, systemPrompt: String): EvalResult {
        val details = ArrayList<QA>()
        for (q in questions) {
            currentCoroutineContext().ensureActive()
            val answer = try { c.chat.answer(q.question, systemPrompt).first } catch (e: CancellationException) { throw e } catch (e: Exception) { "ERROR: ${e.message}" }
            details.add(gradeAnswer(q, answer))
        }
        return EvalResult(if (details.isEmpty()) 0f else details.map { it.score }.average().toFloat(), details)
    }

    /** Scores a question-answering skill (input {question}, output {answer} or a string) on the test set. */
    suspend fun evaluateAnswerSkill(questions: List<TestQuestionEntity>, code: String): EvalResult {
        val details = ArrayList<QA>()
        c.tools.dryRun = true
        try {
            for (q in questions) {
                currentCoroutineContext().ensureActive()
                val r = c.runner.run(code, JSONObject().put("question", q.question).toString(), timeoutMs = 120_000)
                val answer = if (r.ok) skillText(r.value) else "ERROR: ${r.value}"
                details.add(gradeAnswer(q, answer))
            }
        } finally {
            c.tools.dryRun = false
        }
        return EvalResult(if (details.isEmpty()) 0f else details.map { it.score }.average().toFloat(), details)
    }

    private suspend fun gradeAnswer(q: TestQuestionEntity, answer: String): QA {
        if (answer.startsWith("ERROR:")) return QA(q.question, answer, 0f, "answer failed")
        val ref = referenceFor(q)
        if (ref.isBlank()) return QA(q.question, answer, 0f, "knowledge base has no reference for this question")
        val (s, note) = grade(JUDGE_SYSTEM, "REFERENCE:\n$ref\n\nQUESTION: ${q.question}\n\nANSWER:\n${answer.take(3000)}")
        return QA(q.question, answer, s, note)
    }

    /** Scores any other skill by running it on sample inputs and grading its output against its description. */
    suspend fun evaluateGenericSkill(description: String, code: String, inputs: List<String>): EvalResult {
        val details = ArrayList<QA>()
        c.tools.dryRun = true
        try {
            for (inp in inputs) {
                currentCoroutineContext().ensureActive()
                val r = c.runner.run(code, inp, timeoutMs = 120_000)
                if (!r.ok) { details.add(QA(inp, "ERROR: ${r.value}", 0f, "skill failed")); continue }
                val (s, note) = grade(SKILL_JUDGE_SYSTEM, "SKILL PURPOSE: $description\n\nINPUT: $inp\n\nOUTPUT:\n${r.value.take(4000)}")
                details.add(QA(inp, r.value.take(500), s, note))
            }
        } finally {
            c.tools.dryRun = false
        }
        return EvalResult(if (details.isEmpty()) 0f else details.map { it.score }.average().toFloat(), details)
    }

    private fun skillText(json: String): String = try {
        val t = json.trim()
        if (t.startsWith("{")) {
            val o = JSONObject(t)
            o.optString("answer").ifBlank { t }
        } else if (t.startsWith("\"")) JSONArray("[$t]").getString(0) else t
    } catch (e: Exception) {
        json
    }
}
