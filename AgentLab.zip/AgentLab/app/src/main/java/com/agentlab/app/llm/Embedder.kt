package com.agentlab.app.llm

import com.agentlab.app.data.SettingsStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.addJsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.floatOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import kotlinx.serialization.json.putJsonObject
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.nio.ByteBuffer
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.sqrt

class Embedding(val kind: String, val vec: FloatArray)

/**
 * Produces embeddings with the configured provider (Gemini embedContent or an OpenAI-compatible /embeddings endpoint).
 * If the provider has no embedding endpoint (Anthropic) or the call fails, a deterministic local
 * feature-hashing embedding is used so retrieval always works offline.
 */
class Embedder(private val settings: SettingsStore, private val http: OkHttpClient) {
    private val json = Json { ignoreUnknownKeys = true }
    private val jsonType = "application/json".toMediaType()

    suspend fun embed(text: String): Embedding {
        val input = text.take(6000)
        val s = settings.current
        if (s.apiKey.isNotBlank() || s.provider == "OPENAI") {
            try {
                when (s.provider) {
                    "GEMINI" -> if (s.embeddingModel.isNotBlank()) return remoteGemini(input, s.embeddingModel, s.apiKey)
                    "OPENAI" -> if (s.embeddingModel.isNotBlank()) return remoteOpenAi(input, s.embeddingModel, s.baseUrl, s.apiKey)
                    else -> {}
                }
            } catch (e: Exception) {
                // fall through to local embedding
            }
        }
        return Embedding(LOCAL_KIND, localEmbed(input))
    }

    private suspend fun remoteGemini(text: String, model: String, key: String): Embedding {
        val body = buildJsonObject {
            put("model", "models/$model")
            putJsonObject("content") { putJsonArray("parts") { addJsonObject { put("text", text) } } }
            put("outputDimensionality", 768)
        }
        val req = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/$model:embedContent")
            .header("x-goog-api-key", key)
            .post(body.toString().toRequestBody(jsonType)).build()
        val resp = http.newCall(req).await()
        resp.use { r ->
            val txt = withContext(Dispatchers.IO) { r.body?.string().orEmpty() }
            if (!r.isSuccessful) throw LlmException("embed HTTP ${r.code}")
            val arr = json.parseToJsonElement(txt).jsonObject["embedding"].asObj()?.get("values").asArr()
                ?: throw LlmException("no embedding")
            val v = FloatArray(arr.size) { i -> (arr[i] as JsonPrimitive).floatOrNull ?: 0f }
            return Embedding("gemini:$model:${v.size}", normalize(v))
        }
    }

    private suspend fun remoteOpenAi(text: String, model: String, base: String, key: String): Embedding {
        val body = buildJsonObject { put("model", model); put("input", text) }
        val b = Request.Builder().url(base.trimEnd('/') + "/embeddings")
        if (key.isNotBlank()) b.header("Authorization", "Bearer $key")
        val resp = http.newCall(b.post(body.toString().toRequestBody(jsonType)).build()).await()
        resp.use { r ->
            val txt = withContext(Dispatchers.IO) { r.body?.string().orEmpty() }
            if (!r.isSuccessful) throw LlmException("embed HTTP ${r.code}")
            val arr = json.parseToJsonElement(txt).jsonObject["data"].asArr()?.firstOrNull().asObj()
                ?.get("embedding").asArr() ?: throw LlmException("no embedding")
            val v = FloatArray(arr.size) { i -> (arr[i] as JsonPrimitive).floatOrNull ?: 0f }
            return Embedding("openai:$model:${v.size}", normalize(v))
        }
    }

    companion object {
        const val LOCAL_KIND = "local-hash-512"
        private const val DIM = 512

        fun normalize(v: FloatArray): FloatArray {
            var n = 0.0
            for (x in v) n += x * x
            val d = sqrt(n).toFloat()
            if (d == 0f) return v
            return FloatArray(v.size) { v[it] / d }
        }

        fun tokenize(text: String): List<String> =
            text.lowercase().split(Regex("[^\\p{L}\\p{N}]+")).filter { it.length > 1 }

        fun localEmbed(text: String): FloatArray {
            val v = FloatArray(DIM)
            val tokens = tokenize(text)
            val counts = HashMap<String, Int>()
            for (i in tokens.indices) {
                counts.merge(tokens[i], 1, Int::plus)
                if (i + 1 < tokens.size) counts.merge(tokens[i] + " " + tokens[i + 1], 1, Int::plus)
            }
            for ((tok, c) in counts) {
                val h = tok.hashCode() * -1640531535
                val idx = abs((h ushr 4) % DIM)
                val sign = if ((h and 1) == 0) 1f else -1f
                v[idx] += sign * (1f + ln(c.toFloat()))
            }
            return normalize(v)
        }

        fun cosine(a: FloatArray, b: FloatArray): Float {
            if (a.size != b.size || a.isEmpty()) return 0f
            var dot = 0f
            for (i in a.indices) dot += a[i] * b[i]
            return dot
        }

        fun toBytes(v: FloatArray): ByteArray {
            val buf = ByteBuffer.allocate(v.size * 4)
            buf.asFloatBuffer().put(v)
            return buf.array()
        }

        fun fromBytes(b: ByteArray): FloatArray {
            val fb = ByteBuffer.wrap(b).asFloatBuffer()
            val out = FloatArray(fb.remaining())
            fb.get(out)
            return out
        }
    }
}
