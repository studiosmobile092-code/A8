package com.agentlab.app.agent

import com.agentlab.app.data.SettingsStore
import com.agentlab.app.knowledge.Hit
import com.agentlab.app.knowledge.KnowledgeBase
import com.agentlab.app.llm.LlmClient
import com.agentlab.app.llm.LlmMessage
import kotlinx.coroutines.flow.Flow

class Prepared(val messages: List<LlmMessage>, val system: String, val hits: List<Hit>)

/** Retrieval-augmented answering, shared by the Chat screen and the evaluator. */
class ChatEngine(
    private val llm: LlmClient,
    private val kb: KnowledgeBase,
    private val settings: SettingsStore
) {
    suspend fun prepare(question: String, history: List<LlmMessage>, systemOverride: String? = null): Prepared {
        val hits = kb.search(question, 5)
        val ctx = if (hits.isEmpty()) {
            "KNOWLEDGE BASE EXCERPTS: (none relevant)"
        } else {
            "KNOWLEDGE BASE EXCERPTS:\n" + hits.mapIndexed { i, h ->
                "[${i + 1}] ${h.entry.title} (${h.entry.sourceUrl})\n${h.entry.summary}"
            }.joinToString("\n\n")
        }
        val msgs = history + LlmMessage("user", "$ctx\n\nQUESTION: $question")
        return Prepared(msgs, systemOverride ?: settings.current.systemPrompt, hits)
    }

    fun stream(p: Prepared): Flow<String> = llm.stream(p.messages, p.system)

    suspend fun answer(question: String, systemOverride: String? = null): Pair<String, List<Hit>> {
        val p = prepare(question, emptyList(), systemOverride)
        return llm.complete(p.messages, p.system, temperature = 0.2f) to p.hits
    }
}
