package com.agentlab.app.knowledge

import com.agentlab.app.data.AppDb
import com.agentlab.app.data.KnowledgeEntity
import com.agentlab.app.llm.Embedder
import java.security.MessageDigest

data class Hit(val entry: KnowledgeEntity, val score: Float)

class KnowledgeBase(private val db: AppDb, private val embedder: Embedder) {

    private fun hash(text: String): String {
        val norm = text.lowercase().replace(Regex("[^\\p{L}\\p{N}]+"), " ").trim()
        return MessageDigest.getInstance("SHA-256").digest(norm.toByteArray())
            .joinToString("") { "%02x".format(it) }
    }

    /** Returns the new entry id, or null if it was a duplicate. */
    suspend fun add(title: String, summary: String, sourceUrl: String, confidence: Float): Long? {
        val s = summary.trim()
        if (s.length < 20) return null
        val h = hash(s)
        if (db.knowledge().findByHash(h) != null) return null
        val emb = embedder.embed("$title\n$s")
        // Near-duplicate check against entries embedded with the same model.
        for (e in db.knowledge().getAll()) {
            val bytes = e.embedding ?: continue
            if (e.embKind != emb.kind) continue
            if (Embedder.cosine(emb.vec, Embedder.fromBytes(bytes)) > 0.93f) return null
        }
        return db.knowledge().insert(
            KnowledgeEntity(
                title = title.trim().take(200), summary = s, sourceUrl = sourceUrl,
                createdAt = System.currentTimeMillis(), confidence = confidence.coerceIn(0f, 1f),
                contentHash = h, embKind = emb.kind, embedding = Embedder.toBytes(emb.vec)
            )
        )
    }

    suspend fun update(id: Long, title: String, summary: String, confidence: Float) {
        val old = db.knowledge().get(id) ?: return
        val emb = embedder.embed("$title\n$summary")
        db.knowledge().update(
            old.copy(
                title = title.trim(), summary = summary.trim(), confidence = confidence.coerceIn(0f, 1f),
                contentHash = hash(summary), embKind = emb.kind, embedding = Embedder.toBytes(emb.vec)
            )
        )
    }

    suspend fun delete(id: Long) = db.knowledge().deleteById(id)

    /** Hybrid retrieval: embedding cosine (same-model entries) blended with keyword overlap. */
    suspend fun search(query: String, k: Int = 5): List<Hit> {
        val all = db.knowledge().getAll()
        if (all.isEmpty() || query.isBlank()) return emptyList()
        val q = embedder.embed(query)
        val qTokens = Embedder.tokenize(query).toSet()
        val scored = all.map { e ->
            val vec = e.embedding?.takeIf { e.embKind == q.kind }?.let { Embedder.fromBytes(it) }
            val cos = if (vec != null) Embedder.cosine(q.vec, vec) else 0f
            val eTokens = Embedder.tokenize(e.title + " " + e.summary).toSet()
            val kw = if (qTokens.isEmpty()) 0f else qTokens.count { it in eTokens }.toFloat() / qTokens.size
            val score = if (vec != null) 0.75f * cos + 0.25f * kw else kw
            Hit(e, score * (0.8f + 0.2f * e.confidence))
        }
        return scored.filter { it.score > 0.08f }.sortedByDescending { it.score }.take(k)
    }

    suspend fun count(): Int = db.knowledge().count()
}
