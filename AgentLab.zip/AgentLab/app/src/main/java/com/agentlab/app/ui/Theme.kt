package com.agentlab.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Scheme = darkColorScheme(
    primary = Color(0xFF7FD1AE),
    onPrimary = Color(0xFF003827),
    primaryContainer = Color(0xFF0B513B),
    onPrimaryContainer = Color(0xFFA0F2CC),
    secondary = Color(0xFFB4CCBE),
    secondaryContainer = Color(0xFF364B40),
    onSecondaryContainer = Color(0xFFD0E8DA),
    tertiary = Color(0xFFA5CBE0),
    error = Color(0xFFFFB4AB),
    background = Color(0xFF101418),
    onBackground = Color(0xFFE0E3E0),
    surface = Color(0xFF101418),
    onSurface = Color(0xFFE0E3E0),
    surfaceVariant = Color(0xFF3F4944),
    onSurfaceVariant = Color(0xFFBEC9C2),
    surfaceContainer = Color(0xFF1C2024),
    surfaceContainerHigh = Color(0xFF262A2E),
    outline = Color(0xFF89938D)
)

@Composable
fun AgentLabTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}
