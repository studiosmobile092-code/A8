package com.agentlab.app.agent

import com.agentlab.app.Container
import com.agentlab.app.llm.LlmMessage
import com.agentlab.app.skills.SaveResult

/** Lets the model write a new skill, or improve an existing one, then validates it in the sandbox before saving a new version. */
object SkillWriter {
    const val SYSTEM =
        "You write skills for a sandboxed QuickJS (ES2020) engine. A skill is plain JavaScript that defines function run(input) and returns a JSON-serialisable value. " +
            "There is no DOM, no fetch, no require and no async/await: all tools are synchronous. The only tools are:\n" +
            "tools.fetch_url({url}) -> {url,title,text,links[]}\n" +
            "tools.web_search({query,limit}) -> [{title,url,snippet}]\n" +
            "tools.read_knowledge({query,limit}) -> [{id,title,summary,url,confidence}]\n" +
            "tools.save_knowledge({title,summary,url,confidence}) -> {id} or {duplicate:true}\n" +
            "tools.call_llm({prompt,system,temperature,maxTokens}) -> string\n" +
            "tools.run_skill({name,input}) -> any\n" +
            "Tool failures throw Error. Validate input and throw a clear Error when it is missing. Output ONLY the JavaScript source, with no markdown fences and no commentary."

    private fun strip(s: String): String =
        s.trim().removePrefix("```javascript").removePrefix("```js").removePrefix("```").removeSuffix("```").trim()

    suspend fun write(c: Container, name: String, description: String, request: String, existingCode: String? = null): SaveResult {
        var feedback: String? = null
        var last = SaveResult(false, "No attempt made")
        repeat(2) {
            val prompt = buildString {
                append("SKILL NAME: $name\nPURPOSE: $description\nREQUEST: $request\n")
                if (existingCode != null) append("\nEXISTING CODE (keep its input/output contract unless asked otherwise):\n$existingCode\n")
                if (feedback != null) append("\nYOUR PREVIOUS ATTEMPT WAS REJECTED: $feedback\nFix it.\n")
            }
            val code = strip(c.llm.complete(listOf(LlmMessage("user", prompt)), SYSTEM, temperature = 0.3f, maxTokens = 6000))
            last = c.skills.save(name, description, code, "AI: ${request.take(100)}")
            if (last.ok) return last
            feedback = last.error
        }
        return last
    }
}
