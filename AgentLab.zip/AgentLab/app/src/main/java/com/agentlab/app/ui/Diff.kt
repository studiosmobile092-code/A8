package com.agentlab.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

enum class DiffKind { SAME, ADD, DEL }
class DiffLine(val kind: DiffKind, val text: String)

/** Line diff using longest common subsequence. */
fun lineDiff(old: String, new: String): List<DiffLine> {
    val a = old.lines()
    val b = new.lines()
    if (a.size.toLong() * b.size > 4_000_000L) {
        return a.map { DiffLine(DiffKind.DEL, it) } + b.map { DiffLine(DiffKind.ADD, it) }
    }
    val dp = Array(a.size + 1) { IntArray(b.size + 1) }
    for (i in a.size - 1 downTo 0) for (j in b.size - 1 downTo 0) {
        dp[i][j] = if (a[i] == b[j]) dp[i + 1][j + 1] + 1 else maxOf(dp[i + 1][j], dp[i][j + 1])
    }
    val out = ArrayList<DiffLine>()
    var i = 0
    var j = 0
    while (i < a.size && j < b.size) {
        when {
            a[i] == b[j] -> { out.add(DiffLine(DiffKind.SAME, a[i])); i++; j++ }
            dp[i + 1][j] >= dp[i][j + 1] -> { out.add(DiffLine(DiffKind.DEL, a[i])); i++ }
            else -> { out.add(DiffLine(DiffKind.ADD, b[j])); j++ }
        }
    }
    while (i < a.size) out.add(DiffLine(DiffKind.DEL, a[i++]))
    while (j < b.size) out.add(DiffLine(DiffKind.ADD, b[j++]))
    return out
}

@Composable
fun DiffView(old: String, new: String, modifier: Modifier = Modifier) {
    val lines = remember(old, new) { lineDiff(old, new) }
    Column(
        modifier.fillMaxWidth().heightIn(max = 320.dp).verticalScroll(rememberScrollState()).horizontalScroll(rememberScrollState())
    ) {
        for (l in lines) {
            val (bg, prefix) = when (l.kind) {
                DiffKind.ADD -> Color(0x3328A745) to "+ "
                DiffKind.DEL -> Color(0x33F85149) to "- "
                DiffKind.SAME -> Color.Transparent to "  "
            }
            Text(prefix + l.text, fontFamily = FontFamily.Monospace, fontSize = 12.sp, lineHeight = 16.sp, modifier = Modifier.background(bg).fillMaxWidth())
        }
    }
}
