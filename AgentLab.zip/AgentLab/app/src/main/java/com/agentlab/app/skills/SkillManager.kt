package com.agentlab.app.skills

import com.agentlab.app.data.AppDb
import com.agentlab.app.data.SkillEntity
import com.agentlab.app.data.SkillVersionEntity

class SaveResult(val ok: Boolean, val error: String? = null, val version: Int = 0)

class SkillManager(private val db: AppDb, private val runner: SkillRunner) {

    companion object {
        val NAME_RE = Regex("^[a-z][a-z0-9_]{1,39}$")
        const val MAX_DEPTH = 3
    }

    suspend fun ensureDefaults() {
        if (db.skills().getAll().isNotEmpty()) return
        for (d in DefaultSkills.all) save(d.name, d.description, d.code, "Initial version", validate = false)
    }

    /** Saves a new version (history is kept). With validate=true the code must load in the sandbox and define run(input). */
    suspend fun save(name: String, description: String, code: String, note: String, validate: Boolean = true): SaveResult {
        if (!NAME_RE.matches(name)) return SaveResult(false, "Name must be lowercase letters, digits and underscores (2-40 chars, starting with a letter).")
        if (code.isBlank()) return SaveResult(false, "Code is empty.")
        if (code.length > 60_000) return SaveResult(false, "Code is too large (max 60,000 characters).")
        if (validate) {
            val check = runner.run(code, "{}", timeoutMs = 15_000, check = true)
            if (!check.ok) return SaveResult(false, "Code does not load: ${check.value}")
        }
        val existing = db.skills().get(name)
        val version = (existing?.version ?: 0) + 1
        val now = System.currentTimeMillis()
        db.skills().insertVersion(SkillVersionEntity(skillName = name, version = version, code = code, note = note, createdAt = now))
        db.skills().upsert(
            SkillEntity(
                name = name, description = description, code = code, version = version, updatedAt = now,
                enabled = existing?.enabled ?: true, lastGoodVersion = existing?.lastGoodVersion ?: 0
            )
        )
        return SaveResult(true, null, version)
    }

    suspend fun rollback(name: String, toVersion: Int, reason: String = "Rollback"): SaveResult {
        val v = db.skills().getVersion(name, toVersion) ?: return SaveResult(false, "Version $toVersion not found.")
        val cur = db.skills().get(name) ?: return SaveResult(false, "Skill not found.")
        val newVersion = cur.version + 1
        val now = System.currentTimeMillis()
        db.skills().insertVersion(SkillVersionEntity(skillName = name, version = newVersion, code = v.code, note = "$reason (restored v$toVersion)", createdAt = now))
        db.skills().upsert(cur.copy(code = v.code, version = newVersion, updatedAt = now, lastGoodVersion = newVersion))
        return SaveResult(true, null, newVersion)
    }

    suspend fun setEnabled(name: String, enabled: Boolean) {
        db.skills().get(name)?.let { db.skills().upsert(it.copy(enabled = enabled)) }
    }

    suspend fun delete(name: String) {
        db.skills().delete(name)
        db.skills().deleteVersions(name)
    }

    /**
     * Runs a skill. If a freshly edited version crashes (script error, timeout, out of memory) and an earlier
     * version is known to have worked, the skill is automatically rolled back to that version.
     * Returns the result and a note describing any automatic rollback.
     */
    suspend fun run(name: String, inputJson: String, depth: Int = 0, timeoutMs: Long = 90_000): Pair<SkillResult, String?> {
        if (depth >= MAX_DEPTH) return SkillResult(false, "TOOL: run_skill depth limit ($MAX_DEPTH) reached") to null
        val skill = db.skills().get(name) ?: return SkillResult(false, "TOOL: skill '$name' does not exist") to null
        if (!skill.enabled) return SkillResult(false, "TOOL: skill '$name' is disabled") to null
        val res = runner.run(skill.code, inputJson, timeoutMs = timeoutMs, depth = depth)
        if (res.ok) {
            if (skill.lastGoodVersion != skill.version) db.skills().upsert(skill.copy(lastGoodVersion = skill.version))
            return res to null
        }
        if (res.crashed && skill.lastGoodVersion in 1 until skill.version) {
            val rb = rollback(name, skill.lastGoodVersion, "Auto-rollback after crash of v${skill.version}")
            if (rb.ok) {
                val note = "Skill '$name' v${skill.version} crashed (${res.value.take(120)}); rolled back to last working v${skill.lastGoodVersion}."
                return res to note
            }
        }
        return res to null
    }
}
