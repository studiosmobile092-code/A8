# Agent Lab

An Android app (Kotlin, Jetpack Compose, Material 3, minSdk 26) with an AI agent that learns from the web, keeps what it learns in a local knowledge base, tests itself, improves its own prompt / skills / research strategy, and can propose changes to its own source code through GitHub pull requests.

## Honest status

This project was written without access to an Android SDK, so **it has not been compiled or run by its author**. Expect to possibly fix a few compile errors on the first CI build. The GitHub Actions build log shows them exactly, and the app's own GitHub tab can try to fix build failures itself. Items I could not verify: the exact QuickJS setter names for memory/stack limits (set reflectively, so a mismatch cannot break the build, but then the limit is not applied and only the timeout protects you), and Compose/Gradle version compatibility on the first sync.

## Tabs

| Tab | What it does |
|---|---|
| Chat | Streaming chat, saved history, Markdown and code blocks with a copy button. Every message retrieves from the Knowledge base (RAG) and shows which entries it cited. |
| Sources | Add / edit / delete / toggle URLs, topics and search queries. "Read now" reads a source immediately (web pages, GitHub repos + READMEs + docs, PDFs, YouTube transcripts when captions exist). Shows last read, entry count, errors. |
| Knowledge | Browse, semantic-search, edit, delete, and add entries. Each shows summary, source URL, date and confidence. Stored locally in SQLite (Room) with embeddings. |
| Skills | JavaScript skills run in QuickJS inside a separate process. Code editor with line numbers, test run, AI write/improve, version history, one-tap rollback. |
| Settings | Provider (Gemini default, OpenAI-compatible, Anthropic), model list, encrypted API key, temperature, max tokens, system prompt, research strategy, search provider, GitHub token and repo, limits. |
| Agent | RUN / STOP, live log, Changes (diff + Approve/Reject + auto-approve toggle + before/after scores), Tests (editable test questions), GitHub (self-rewrite tasks). |

## How RUN works

1. **Research**: reads all enabled sources, runs web searches for topics/queries, follows links the model picks as useful (depth and page limits in Settings).
2. **Learn**: the model extracts facts, which are de-duplicated (hash plus embedding similarity), quality-rated and stored with their source URL.
3. **Evaluate**: your test questions plus questions generated from what it learned are answered through the normal RAG pipeline and graded 0 to 10 by the model against a reference (your reference answer, or the knowledge base).
4. **Improve**: from the weak answers it proposes changes to (a) the system prompt, (b) a skill script, (c) the research strategy.
5. **Test**: each change is tested in a sandbox (prompt: re-answer the set; strategy: re-extract sample pages into temporary entries, re-answer, then delete them; skill: run old vs new code in the sandbox with writes disabled). A change is kept only if the score rises by more than 0.5 points of percentage margin; otherwise it is rolled back automatically and logged with both numbers.
6. **Approval**: kept changes appear as diffs with the reason. Approve or Reject. The "auto-approve" toggle (off by default) applies improved changes automatically.

Scores are produced by an LLM grader, so they are noisy. Use enough test questions (Settings, default 10) before trusting small differences.

## Skills

A skill is JavaScript that defines `function run(input)` and returns JSON-serialisable data. Tools are synchronous and are the only thing a skill can reach:

```
tools.fetch_url({url})                               -> {url,title,text,links[]}
tools.web_search({query,limit})                      -> [{title,url,snippet}]
tools.read_knowledge({query,limit})                  -> [{id,title,summary,url,confidence}]
tools.save_knowledge({title,summary,url,confidence}) -> {id} | {duplicate:true}
tools.call_llm({prompt,system,temperature,maxTokens})-> string
tools.run_skill({name,input})                        -> any   (max nesting depth 3)
```

No files, contacts or other apps. Skills run in a dedicated Android process (`:sandbox`). The app enforces a wall-clock timeout (90 s per run) by killing that process, so even an infinite loop cannot hang the app. Every save creates a version. If a newly edited version crashes (script error, timeout, memory) and an earlier version is known to have worked, it is rolled back automatically.

Starter skills: `summarize_url`, `research_topic`, `answer_from_knowledge`, `build_website`. Use "AI skill" in the Skills tab to have the model write new ones (it validates the code in the sandbox before saving).

## GitHub self-rewrite loop

In Agent > GitHub create a task ("Add a dark/light toggle", and so on). The agent then:

1. creates a branch `agentlab/<task>-<timestamp>` from your base branch,
2. picks the files to read, asks the model for complete new file contents, and makes **one commit** through the Git Data API,
3. opens a pull request with an explanation,
4. waits for the GitHub Actions build; on failure it reads the failed job log, asks the model for a fix, and pushes again (**at most 3 fix pushes per task**),
5. shows build status and a link to the run page where the APK artifact can be downloaded.

The client refuses to write to the base branch, `main` or `master`. It cannot change `.github/` or `gradle/wrapper`. You merge.

Limits: files are read up to 30,000 characters and returned as whole files, so large rewrites can exceed the model's output limit. Raise Max tokens or split the task.

## Setup: from zero to an installed APK

1. **Create the repo.** On github.com create a new empty repository (private is fine), for example `agent-lab`.
2. **Push this project.**
   ```bash
   cd AgentLab
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/<you>/agent-lab.git
   git push -u origin main
   ```
3. **Get the APK.** Open the repo's **Actions** tab, open the latest "Build APK" run, scroll to **Artifacts**, download `agent-lab-debug-apk`, and unzip it to get `app-debug.apk`. If the build fails, open the failing step: it lists the compile error.
4. **Sideload onto the tablet.** Copy `app-debug.apk` to the tablet (USB, cloud drive, or download it on the tablet directly). Open it and allow "Install unknown apps" for the app you opened it from when asked.
5. **Add your API key.** Get a Gemini key at https://aistudio.google.com/apikey. In the app: Settings > Model provider > API key > Save. Tap "List available models" to pick a model.
6. **Add your GitHub token (for self-rewriting).** On GitHub: Settings > Developer settings > Personal access tokens > **Fine-grained tokens**, limited to this one repository, with permissions **Contents: Read and write**, **Pull requests: Read and write**, **Actions: Read**, **Metadata: Read**. Paste it in Settings > GitHub, set the repository as `<you>/agent-lab`, base branch `main`, and Save. Tip: also protect `main` in the repo's branch settings.
7. **Teach it.** Sources > Add a link or topic, then Agent > RUN.

## Notes

- API keys and tokens are stored with AndroidX Security `EncryptedSharedPreferences` (AES-256, Android Keystore).
- Web search defaults to DuckDuckGo's HTML endpoint, which may refuse automated requests. For reliable search add a Tavily or Brave key in Settings.
- Embeddings use your provider's embedding endpoint (Gemini / OpenAI-compatible). If unavailable (for example Anthropic) the app falls back to on-device hashed embeddings, so retrieval still works offline.
- Daily token budget: counted from provider usage data when available, estimated otherwise. Runs stop when it is exhausted.
- A foreground-service notification is shown while the agent runs so Android keeps it alive.
- Local build: install JDK 17 and Android SDK 34, then run `gradle assembleDebug` (Gradle 8.9 or newer; run `gradle wrapper` once if you want a `gradlew`).

## Project layout

```
.github/workflows/build.yml      CI: builds the debug APK on every push and PR, uploads it
gradle/libs.versions.toml        version catalog
app/src/main/java/com/agentlab/app/
  MainActivity.kt, AgentLabApp.kt (wiring)
  data/        Room database, encrypted settings
  llm/         LLM client (streaming), embeddings
  web/         page/PDF/GitHub/YouTube reader, web search
  knowledge/   knowledge base with hybrid retrieval
  skills/      QuickJS sandbox service, runner, manager, tools, starter skills
  agent/       chat engine, researcher, evaluator, improver, controller, service
  github/      GitHub API client, self-editing loop
  ui/          Compose screens
```
